////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                         PROPRIETARY RIGHTS NOTICE:                         //
//                                                                            //
//         ALL RIGHTS RESERVED. THIS MATERIAL CONTAINS THE VALUABLE           //
//                      PROPERTIES AND TRADE SECRETS OF                       //
//                                                                            //
//                                 Itron,                                     //
//                           BANGALORE, INDIA                                 //
//                                                                            //
//                  EMBODYING SUBSTANTIAL CREATIVE EFFORTS                    //
//   AND TRADE SECRETS, CONFIDENTIAL INFORMATION, IDEAS AND EXPRESSIONS, NO   //
//    PART OF WHICH MAY BE REPRODUCED OR TRANSMITTED IN ANY FORM OR BY ANY    //
//   MEANS ELECTRONIC, MECHANICAL, OR OTHERWISE, INCLUDING PHOTOCOPYING AND   //
//        RECORDING OR IN CONNECTION WITH ANY INFORMATION STORAGE OR          //
//         RETRIEVAL SYSTEM WITHOUT THE PERMISSION IN WRITING FROM            //
//                                  Itron, Inc.                               //
//                                                                            //
//                                 COPYRIGHT 2016                             //
//                                  Itron. Inc.                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

/*!************************************************************************//**
 * @file          agent_metrology.h
 * @brief         Implements metrology interfacing with APP SDK
 * @date          05.Dec.2016
 * @author        Ruchi Nag
 ******************************************************************************/

#ifndef _AGENT_METROLOGY_H_
#define _AGENT_METROLOGY_H_

#include <agent_types.h>
#include <common.h>

void SubscribeToMetrologyData(void);
void UnSubscribeFromMetrologyData();
void ProcessLids(const stMetrologyLids& i_lidData);
bool IsAgentFeatureEnabled();

//void UpdateAgentConfigurations (const stGeneralConfig iGenConfig, const stSigChangeConfig iSigConfig, 
//								const stRegressionConfig iRegConfig, 
//								const stImpdChangeConfig iImpIncConfig, const stImpdChangeConfig iImpDecConfig);

void SubscribeLids();

#endif  // _AGENT_METROLOGY_H_
