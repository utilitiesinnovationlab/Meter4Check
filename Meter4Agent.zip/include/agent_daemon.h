////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                         PROPRIETARY RIGHTS NOTICE:                         //
//                                                                            //
//         ALL RIGHTS RESERVED. THIS MATERIAL CONTAINS THE VALUABLE           //
//                      PROPERTIES AND TRADE SECRETS OF                       //
//                                                                            //
//                                 Itron,                                     //
//                           BANGALORE, INDIA                                 //
//                                                                            //
//                  EMBODYING SUBSTANTIAL CREATIVE EFFORTS                    //
//   AND TRADE SECRETS, CONFIDENTIAL INFORMATION, IDEAS AND EXPRESSIONS, NO   //
//    PART OF WHICH MAY BE REPRODUCED OR TRANSMITTED IN ANY FORM OR BY ANY    //
//   MEANS ELECTRONIC, MECHANICAL, OR OTHERWISE, INCLUDING PHOTOCOPYING AND   //
//        RECORDING OR IN CONNECTION WITH ANY INFORMATION STORAGE OR          //
//         RETRIEVAL SYSTEM WITHOUT THE PERMISSION IN WRITING FROM            //
//                                  Itron, Inc.                               //
//                                                                            //
//                                 COPYRIGHT 2016                             //
//                                  Itron. Inc.                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

/*!************************************************************************//**
 * @file          agent_daemon.h
 * @brief         Main Agent Daemon File
 * @date          15.08.2017
 * @author        Deepika Durgvanshi
 ******************************************************************************/

#ifndef _AGENT_DAEMON_H_
#define _AGENT_DAEMON_H_

const std::string kstrCommandFeatureId = COMMANDFEATUREID;
const uint32_t kuiCommandConfigFeatureID = static_cast<uint32_t>(strtoul(kstrCommandFeatureId.c_str(), NULL, 16));

const std::string kstrGenericFeatureId = GENERICFEATUREID;
const uint32_t kuiGenericFeatureID = static_cast<uint32_t>(strtoul(kstrGenericFeatureId.c_str(), NULL, 16));

const std::string kstrConfigFeatureId = CONFIGFEATUREID;
const uint32_t kuiConfigFeatureID = static_cast<uint32_t>(strtoul(kstrConfigFeatureId.c_str(), NULL, 16));


#endif // _AGENT_DAEMON_H_



