////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                         PROPRIETARY RIGHTS NOTICE:                         //
//                                                                            //
//         ALL RIGHTS RESERVED. THIS MATERIAL CONTAINS THE VALUABLE           //
//                      PROPERTIES AND TRADE SECRETS OF                       //
//                                                                            //
//                                 Itron,                                     //
//                           BANGALORE, INDIA                                 //
//                                                                            //
//                  EMBODYING SUBSTANTIAL CREATIVE EFFORTS                    //
//   AND TRADE SECRETS, CONFIDENTIAL INFORMATION, IDEAS AND EXPRESSIONS, NO   //
//    PART OF WHICH MAY BE REPRODUCED OR TRANSMITTED IN ANY FORM OR BY ANY    //
//   MEANS ELECTRONIC, MECHANICAL, OR OTHERWISE, INCLUDING PHOTOCOPYING AND   //
//        RECORDING OR IN CONNECTION WITH ANY INFORMATION STORAGE OR          //
//         RETRIEVAL SYSTEM WITHOUT THE PERMISSION IN WRITING FROM            //
//                                  Itron, Inc.                               //
//                                                                            //
//                                 COPYRIGHT 2016                             //
//                                  Itron. Inc.                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

/*!************************************************************************//**
 * @file          agent_types.h
 * @brief         Types and constants for Sudden Change
 * @date          21.Apr.2017
 * @author        Ruchi Nag
 ******************************************************************************/

#ifndef _AGENT_TYPES_H_
#define _AGENT_TYPES_H_

#include <diagent_log.h>

struct stGeneralConfig
{
	bool uiFeatureEnabled;
	common::ELogLevel uiLogLevel;
	uint32_t uiKeepLogLevelForSecs;
};


struct stAgentFeatureConfig
{
	uint32_t VoltThreshold;
	bool CheckForVoltage;
    uint32_t CurrentThreshold;
	bool CheckForCurrent; 
    uint32_t TamperThreshold;
    bool CheckForTamper;

};

struct FeatureStatus
{
	bool bIsGenericFeatureStarted;
	bool bIsAgentFeatureStarted;
	bool bIsCommandExecStarted;
	bool bIsConfigFeatureStarted;
};

/**
* Metrology data read from the platform
*/
struct stlids_Value
{
	uint64_t ulTimeStamp;
	double dVoltageA;
	double dCurrentA;
	double dVoltageB;
	double dCurrentB;
	double dVoltageC;
	double dCurrentC;
    double dLid_INS_VAS_AGGREGATE;
    double dLid_INS_VAR_AGGREGATE;
    double dLid_INS_WATTS_AGGREGATE;
    double dLid_INS_TEMPERATURE_CELCIUS;
    double dLid_INS_POWER_FACTOR;
    double dLid_INS_VAB_ANGLE;
    double dLid_INS_VAC_ANGLE;
    double dLid_INS_VA_PHA;
    double dLid_INS_VA_PHB;
    double dLid_INS_VA_PHC;
    double dLid_INS_W_PHA;
    double dLid_INS_W_PHB;
    double dLid_INS_W_PHC;
    double dLid_INS_VAR_PHA;
    double dLid_INS_VAR_PHB;
    double dLid_INS_VAR_PHC;
    double dLid_CPC_DATA_INSTLOADVOLTAGEPHA;
    double dLid_CPC_DATA_INSTLOADVOLTAGEPHB;
    double dLid_CPC_DATA_INSTLOADVOLTAGEPHC;
    double dLid_INS_CURRENT_ANGLE_PHA;
    double dLid_INS_CURRENT_ANGLE_PHB;
    double dLid_INS_CURRENT_ANGLE_PHC;
    double dLid_NEUTRAL_CURRENT_MEASURED;
    double dLid_NEUTRAL_CURRENT_CALCULATED;
    double dLid_NEUTRAL_CURRENT_TAMPER;
    double dLid_INS_FREQUENCY;
};

#endif //_AGENT_TYPES_H_
