////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                         PROPRIETARY RIGHTS NOTICE:                         //
//                                                                            //
//         ALL RIGHTS RESERVED. THIS MATERIAL CONTAINS THE VALUABLE           //
//                      PROPERTIES AND TRADE SECRETS OF                       //
//                                                                            //
//                                 Itron,                                     //
//                           BANGALORE, INDIA                                 //
//                                                                            //
//                  EMBODYING SUBSTANTIAL CREATIVE EFFORTS                    //
//   AND TRADE SECRETS, CONFIDENTIAL INFORMATION, IDEAS AND EXPRESSIONS, NO   //
//    PART OF WHICH MAY BE REPRODUCED OR TRANSMITTED IN ANY FORM OR BY ANY    //
//   MEANS ELECTRONIC, MECHANICAL, OR OTHERWISE, INCLUDING PHOTOCOPYING AND   //
//        RECORDING OR IN CONNECTION WITH ANY INFORMATION STORAGE OR          //
//         RETRIEVAL SYSTEM WITHOUT THE PERMISSION IN WRITING FROM            //
//                                  Itron, Inc.                               //
//                                                                            //
//                                 COPYRIGHT 2016                             //
//                                  Itron. Inc.                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

/*!************************************************************************//**
* @file          agent_constants.h
* @brief         Agent configuration file
* @date          August 19, 2017
* @author        Deepika
******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <stdint.h>

#ifndef _AGENT_CONSTANTS_H_
#define _AGENT_CONSTANTS_H_

// ***************************************************************************
// CONSTANTS
// ***************************************************************************
/*Agent configurations*/

static const uint32_t kuiServiceID = 0x01;
static const uint32_t kuiPhase = 0x01;
static const uint32_t kuiAgentID = 0x23020004;
static const uint32_t kuiAgentVersion = 1U;


static const uint32_t kuiAgentFeatureID = 0x23030004;
static const uint16_t kuiMinDiffInterval = 5;
static const uint16_t theftTimeDiffTH = 1;
static const uint16_t kuiMinDiffPercentage = 3;

#ifndef BUILD_FOR_DAVINCI 
const uint8_t kbyStartUpMsgEvntType = 12U;
#endif
const uint8_t kbyStartUpMsgType = 98U;

enum eFeatureIndex
{
	GENERICFEATURE,
	AGENTFEATURE,
	COMMANDEXECUTION,
	CONFIGFEATURE
};

//static const uint8_t kbyAllowedNumberOfFeatures= 1;
//static const uint32_t kauiAllowedFeatures[] = {0x1};
//static const std::string kastrFeatureName[]={"SigEvent"};// for each feature
//static const unsigned char kagentTmpPath[] = "/tmp/agent/";
//static const std::string kstrCmdFilePath="/tmp/agent/" AGENTID "/" AGENTID ".cmd";
//static const std::string kstrStatusFilePath="/tmp/agent/" AGENTID "/" AGENTID ".status";


#endif /*_AGENT_CONSTANTS_H_*/
