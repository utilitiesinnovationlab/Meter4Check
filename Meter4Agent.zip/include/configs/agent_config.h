////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                         PROPRIETARY RIGHTS NOTICE:                         //
//                                                                            //
//         ALL RIGHTS RESERVED. THIS MATERIAL CONTAINS THE VALUABLE           //
//                      PROPERTIES AND TRADE SECRETS OF                       //
//                                                                            //
//                                 Itron,                                     //
//                           BANGALORE, INDIA                                 //
//                                                                            //
//                  EMBODYING SUBSTANTIAL CREATIVE EFFORTS                    //
//   AND TRADE SECRETS, CONFIDENTIAL INFORMATION, IDEAS AND EXPRESSIONS, NO   //
//    PART OF WHICH MAY BE REPRODUCED OR TRANSMITTED IN ANY FORM OR BY ANY    //
//   MEANS ELECTRONIC, MECHANICAL, OR OTHERWISE, INCLUDING PHOTOCOPYING AND   //
//        RECORDING OR IN CONNECTION WITH ANY INFORMATION STORAGE OR          //
//         RETRIEVAL SYSTEM WITHOUT THE PERMISSION IN WRITING FROM            //
//                                  Itron, Inc.                               //
//                                                                            //
//                                 COPYRIGHT 2016                             //
//                                  Itron. Inc.                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

/*!************************************************************************//**
 * @file          agent_config.h
 * @brief         Types and constants for Significant changes
 * @date          05.Dec.2016
 * @author        Ruchi Nag
 ******************************************************************************/
#ifndef _AGENT_CONFIG_H_
#define _AGENT_CONFIG_H_

#include <common.h>
#include <command.h>
#include <agent_daemon.h>
using namespace common;

static const std::string folder_general("General");
static const std::string FeatureState("FeatureState");
static const std::string LogLevel("LogLevel");
static const std::string KeepLogLevelForSecs("KeepLogLevelForSecs");

static const std::string folder_AgentFeature("AgentFeature");
static const std::string ThresholdVoltage("ThresholdVoltage");
static const std::string CheckForVoltage("CheckForVoltage");

static const std::string folder_AllLids("AllLids");
static const std::string SubscribeAllLids("SubscribeAllLids");

static const string strTestCommand("TestCommand");

//names of parameters for coutLogger
static const std::string strFolderCoutLogger("CoutLogger");
static const std::string strCoutEnabled("IsEnabled");
static const std::string strNumLogFiles("NumFiles");
static const std::string strLogFileSize("FileSize");
static const std::string strFolderCallBackForHungAgent("CallBackForHungAgent");
static const std::string strCallBackTimeOutSec("CallBackTimeOutSec");
static const std::string strFolderConfig("Configuration");
static const std::string strFolderArrayBuffer("ArrayBuffer");
static const std::string strArrayBufferSize("BufferSize");

// Default general configs
static const uint8_t kDefaultFeatureEnabled = false;
static const common::ELogLevel kDefaultLogLevel = common::ALERT;
static const common::ELogLevel kDefaultRevertLogLevel = common::ALERT;
static const uint16_t kDefaultKeepLogLevelForSecs = 180U;

// Default Configuration Values for AgentFeature
static const uint32_t kDefaultVBelowThreshold = 231;
static const uint8_t kDefaultCheckForVolt = true;
static const uint32_t kDefaultCBelowThreshold = 27;
static const bool kDefaultCheckForCurrent = true;
static const uint32_t kDefaultTBelowThreshold = 0;
static const bool kDefaultCheckForTamper = true;

/**
 * @brief This function is use to initialize configuration values for the feature
 */
void InitializeFeatureConfigModule();


/**
 * @brief This function is the callback function, which use to Set AgentFeature Log Level parameter value
 *
 * @param[in] i_folderName Folder name of the configuration parameter
 * @param[in] i_paramName Parameter name of the configuration value
 * @param[in] i_stConfigVal Parameter value and type
 *
 */
void SetAgentFeatureGenLogLevelCB(string i_folderName, string i_paramName, stConfigVal i_stConfigVal);

/**
 * @brief This function is the callback function, which use to Set AgentFeature FeatureEnabled parameter value
 *
 * @param[in] i_folderName Folder name of the configuration parameter
 * @param[in] i_paramName Parameter name of the configuration value
 * @param[in] i_stConfigVal Parameter value and type
 *
 */
void SetAgentFeatureGenFeatureEnabledCB(string i_folderName, string i_paramName, stConfigVal i_stConfigVal);

/**
 * @brief This function is the callback function, which use to Set AgentFeature KeepLogLevelForSecs parameter value
 *
 * @param[in] i_folderName Folder name of the configuration parameter
 * @param[in] i_paramName Parameter name of the configuration value
 * @param[in] i_stConfigVal Parameter value and type
 *
 */
void SetAgentFeatureGenKeepLogLevelForSecsCB(string i_folderName, string i_paramName, stConfigVal i_stConfigVal);


/**
 * @brief This function is the callback function, which use to Set AgentFeature ThresholdVoltage parameter value
 *
 * @param[in] i_folderName Folder name of the configuration parameter
 * @param[in] i_paramName Parameter name of the configuration value
 * @param[in] i_stConfigVal Parameter value and type
 *
 */
void SetAgentFeatureThresholdVoltageCB(string i_folderName, string i_paramName, stConfigVal i_stConfigVal);

/**
 * @brief This function is the callback function, which use to Set AgentFeature  CheckForVoltage parameter value
 *
 * @param[in] i_folderName Folder name of the configuration parameter
 * @param[in] i_paramName Parameter name of the configuration value
 * @param[in] i_stConfigVal Parameter value and type
 *
 */
void SetAgentFeatureCheckForVoltageCB(string i_folderName, string i_paramName, stConfigVal i_stConfigVal);

/**
 * @brief This function is the callback function, which use to Set AllLids parameter value
 *
 * @param[in] i_folderName Folder name of the configuration parameter
 * @param[in] i_paramName Parameter name of the configuration value
 * @param[in] i_stConfigVal Parameter value and type
 *
 */
void SetAllLidsCB(string i_folderName, string i_paramName, stConfigVal i_stConfigVal);

#endif // _AGENT_CONFIG_H_
