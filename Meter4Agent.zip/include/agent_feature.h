/*
 * agent_feature.h
 *
 *  Created on: 14-Aug-2017
 *      Author: itron
 */

#ifndef CAGENTFEATURE_H_
#define CAGENTFEATURE_H_

#include <agent_types.h>
#include <Common_Util.h>
#include <queue>
#include <list>

class CAgentFeature
{
    //Public variables
public:
    typedef struct electrictParam{
        double m_dblVoltage_A;
        double m_dblVoltage_B;
        double m_dblVoltage_C;
        double m_dblCurrent_A;
        double m_dblCurrent_B;
        double m_dblCurrent_C;
        double m_dblPFactor;
    } elecParam;

public:

	CAgentFeature();

    ~CAgentFeature();
    void InitializeConfig();
    void checkVoltagestatus(const stMetrologyLids& i_stMetData);
    void UpdateAgentFeatureConfig(const stGeneralConfig i_GenAgentFeatureConfig, const stAgentFeatureConfig  i_AgentFeatureConfig);
    /*  */
    void checkCurrentstatus(const stMetrologyLids& i_stMetData);
    void checkTamperstatus(const stMetrologyLids& i_stMetData);
    int CheckSupplyVoltage(const stMetrologyLids& i_stMetData);
    void TheftDetection(const stMetrologyLids& i_stMetData);
    double CheckCurrentDeviationforTheft(const stMetrologyLids& i_stMetData);
    void ElectParamDataStorage(const stMetrologyLids& i_stMetData);
    elecParam AvgCalculation(int size);
    int CheckPFactorDeviationforTheft(const stMetrologyLids& i_stMetData, elecParam& avgParam);
    int CheckCurrentVoltageDeviationforTheft(const stMetrologyLids& i_stMetData, elecParam& avgParam, elecParam& avgParamMicro);
    void MakeDecission(const stMetrologyLids& i_stMetData, int res, double diff);
    void PowerCalculation(double dblVoltageA, double dblCurrentA, double dblVoltageB, double dblCurrentB, double dblPF);

private:
    bool m_alarmstat;
    bool m_tamperAlarmStat;
    bool m_isAlarmSent;
    bool m_theftAlarmStat; //Line Added by PS
    uint64_t m_tamperStartTime; 
    uint64_t m_theftStartTime;
    double m_Power;
    uint64_t m_eventID;
    void sendAlarm(const stMetrologyLids& i_stMetData);
    stAgentFeatureConfig m_AgentFeatureConfig;
    stGeneralConfig m_genConfig;
    /*  */
    void sendCurrentAlarm(const stMetrologyLids& i_stMetData);
    void sendTamperAlarm(const stMetrologyLids& i_stMetData);
    double m_dblavgCurrent_A;
    double m_dblavgCurrent_B;
    double m_dblavgCurrent_C;
 // double m_dblavgCurrent_ABC;   //Line Added by PS
    double m_dblavgVoltage_A;
    double m_dblavgVoltage_B;
    double m_dblavgVoltage_C;
 // double m_dblavgVoltage_ABC;
    double m_dblPFactorAvg;
    list<elecParam> m_elecParam;
    list<elecParam> m_elecParamMicro;
    void sendTheftAlarm(const stMetrologyLids& i_stMetData);
    int m_theftPFCounter1;
    int m_theftPFCounter2;
    int m_theftVoltCounter1;
	int m_theftVoltCounter2;
	int m_theftVoltCounter3;
	int m_theftVoltCounter4;
    bool m_theftVoltCurrentAlarmStat;
    bool m_theftCurrentDeviationAlarmStat;
    bool m_theftPFCurrentAlarmStat;
    bool m_initialTeftDetection;
    double m_theftPower;
    uint64_t addTime;
    /*int m_theftVAcounter;
    int m_theftStatusPF240;
    int m_theftStatusPF120;
    int m_theftPFCount240;
    int m_theftPFCount120;*/
};



#endif /* CAGENTFEATURE_H_ */
