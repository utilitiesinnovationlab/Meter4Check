////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                         PROPRIETARY RIGHTS NOTICE:                         //
//                                                                            //
//         ALL RIGHTS RESERVED. THIS MATERIAL CONTAINS THE VALUABLE           //
//                      PROPERTIES AND TRADE SECRETS OF                       //
//                                                                            //
//                                 Itron,                                     //
//                           BANGALORE, INDIA                                 //
//                                                                            //
//                  EMBODYING SUBSTANTIAL CREATIVE EFFORTS                    //
//   AND TRADE SECRETS, CONFIDENTIAL INFORMATION, IDEAS AND EXPRESSIONS, NO   //
//    PART OF WHICH MAY BE REPRODUCED OR TRANSMITTED IN ANY FORM OR BY ANY    //
//   MEANS ELECTRONIC, MECHANICAL, OR OTHERWISE, INCLUDING PHOTOCOPYING AND   //
//        RECORDING OR IN CONNECTION WITH ANY INFORMATION STORAGE OR          //
//         RETRIEVAL SYSTEM WITHOUT THE PERMISSION IN WRITING FROM            //
//                                  Itron, Inc.                               //
//                                                                            //
//                                 COPYRIGHT 2016                             //
//                                  Itron. Inc.                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

/*!************************************************************************//**
 * @file          agent_daemon.cpp
 * @brief         Main Agent Daemon File
 * @date          16.Aug.2017
 * @author        Deepika Durgvanshi
 ******************************************************************************/

//#define NODAEMON
//#define debugDaemon

// System Headers
#include <unistd.h>     // for fork()
#include <sys/stat.h>   // got umask()
#include <ios>

// Module headers
#include <agent_constants.h>
#include <agent_daemon.h>
#include <agent_metrology.h>
#include <agent_config.h>
#include <common.h>
#include <Itron/AgentApi.h>
#include <Common_Util.h>
#include <common_diag.h>
#include <mytimer.h>
#include <data_to_server.h>
#include <common_metrology.h>
#include <Itron/lids.h>
#define SYSTEM_FW_VERSION_LID 1083965465

#ifdef debugDaemon
#define dcout(str) do { cout << "[Agent Daemon]. " << str << std::"\n"; } while( false )
#else
#define dcout(str) do { } while ( false )
#endif
struct FeatureStatus g_stFeaturesStatus;
extern bool g_FeatureUsrSignal;

static const uint8_t kbyAllowedNumberOfFeatures = 4;
static const std::string kstrCmdFilePath="/tmp/agent/" AGENTID "/" AGENTID ".cmd";
static const std::string kstrStatusFilePath="/tmp/agent/" AGENTID "/" AGENTID ".status";

static const std::string kastrFeatureName[]={"GenericFeature", "AgentFeature", "CommandExecution", "ConfigFeature"} ;// for each feature
static const uint32_t kauiAllowedFeatures[] = {kuiGenericFeatureID, kuiAgentFeatureID, kuiCommandConfigFeatureID, kuiConfigFeatureID};
static uint8_t g_abyOrderOfFeature[]={0, 0, 0, 0};
bool g_abPresentStatus[]={false, false, false, false};
extern bool  g_bIsCoutLogByThread;
extern bool  g_bIsLogToServerByThread;

std::ostringstream gStrmEnabledFeatures, gStrmDisabledFeatures;
static bool gFeatureStatusUpdated = false;

static void Run(void);
static void Finalize(void);
static void SignalHandler(int i_iSigNum);//!OCLINT
static bool Initialize(void);

/**
 * @brief Converts the value returned by SDK APIs to string
 *
 * @param[in] i_value Value to be converted to string
 *
 * @returns the input as string
 */
static string ApiVariableType_GetString(ApiVariableType i_value);

/**
 * @brief Send an alarm message when the agent starts or any feature is enabled or disabled
 *
 * @param[in] i_strEnabledFeatures List if enabled features
 * @param[in] i_strDisabledFeatures List if disabled features
 *
 */
static void LogAgentStartupMessage(const string &i_strEnabledFeatures, const string &i_strDisabledFeatures);

void GetConfigValidation();

bool GetInitialConfigurationFromDB();

common::ELogLevel daemonLogLevel = kDefaultLogLevel;

static bool g_bDoSubscribe = false ;

extern "C" int main(int argc, char* argv[])//!OCLINT
{
    /* Set agent id */
	setAgentId(kuiAgentID);

    /* Set Overlay ID */
    SetOverlayId(static_cast<uint32_t>(atol(OVERLAYID_DEC)));

    /* Set FlashPath */
    SetFlashPath(FLASHPATH);

#ifdef FASTSIM 	
    CCommonMetrology::m_bIsFastSimulationEnabled = true;
#endif
    #ifdef debugDaemon
       cout << "AgentDaemon.main()" << endl ;
    #endif

   #ifndef NODAEMON
    pid_t process_id = 0;
    pid_t sid = 0;
    process_id = fork();            // Create child process
    if (process_id < 0)             // Indication of fork() failure
    {
        // to do 
        exit(1);
    }

    if (process_id > 0)             // Parent Process. Need to kill it.
    {
        exit(0);                    // return success in exit status
    }

    umask(0);                       //unmask the file mode

    sid = setsid();                 //set new session
    if(sid < 0)
    {
        ApiLogDebugMessage("Error | fail to setsid", 32);
        exit(1);
    }
    #endif

    int ret1 = chdir("/");  // Change the current working directory to root.


    if(ret1!=0)
    {
        #ifdef debugDaemon
    	cout <<"Unable to change to root directory";
        #endif
    	common::DIAgentLogMsg(kuiPhaseA, kuiAgentFeatureID, daemonLogLevel, common::ALERT,common::GENERAL,"In Main(): Fail to Change the current working directory to root.  chdir. Feature: %d, ErrorCode: %d", kuiAgentFeatureID, ret1);
    }


    #ifndef debugDaemon
    close(STDIN_FILENO);          // Close stdin. stdout and stderr
    close(STDOUT_FILENO);         // Commenting so that debug logs visible on console
    close(STDERR_FILENO);
    #endif

    bool ret = Initialize() ;
    cout << "ret value before Run(): "<<ret;
    if (ret)
    {
        Run();
    }
    else
    {

        #ifdef debugDaemon
          cout << "AgentDaemon.Error | fail to Initialize Agent" << endl;
        #endif 
	    common::DIAgentLogMsg(kuiPhaseA, kuiAgentFeatureID, daemonLogLevel, common::ALERT,common::GENERAL,"In Main(): Fail to Initialize Agent.  Initialize. Feature: %d, ErrorCode: %d", kuiAgentFeatureID, ret);
	}
	return 0;
}

static bool Initialize(void)
{

    #ifdef debugDaemon
        cout << "AgentDaemon.Initialize()" << endl ;
    #endif
    //g_abPresentStatus[AGENTFEATURE] = true;
    bool bResult = false;
	CCommonMetrology::Initialize(ProcessLids, kuiAgentFeatureID);

    /*register signal handler*/
    signal(SIGUSR1, SignalHandler);
    signal(SIGINT, SignalHandler);
    signal(SIGTERM, SignalHandler);
    signal(SIGKILL, SignalHandler);
    signal(SIGSEGV, SignalHandler);

   // g_stFeaturesStatus.bIsSigChangeStarted = true;

    /*Registering the Agent to platform*/
    AgentApiReturnType result;
    bool isRegistrationStatusLogged = false;
    do
    {
	    result = apiRegisterAgent (kuiAgentID, "Meter4Agent", "Meter 4 Agent");

	    if(API_SUCCESS == result)
	    {

	    	//To enable CoutLogging through Thread
	    	g_bIsCoutLogByThread = true;
	    	g_bIsLogToServerByThread = true;
		    common::DIAgentLogMsg(kuiPhaseA, kuiAgentFeatureID, daemonLogLevel, common::DEBUG,common::GENERAL,"AgentDaemon registered successfully");

			#ifdef debugDaemon
		    cout << "AgentDaemon.Agent Registration success" << endl;
			#endif

		    initialize(); //Initialize mytimer from mytimer.cpp

		    SubscribeLids();
		    InitializeFeatureConfigModule();  //Initialize Description configuration and parameter callback
   		    bResult = true;
	    }
	    else
	    {
	    	if( false == isRegistrationStatusLogged )
    		{
	    		#ifdef debugDaemon
	    		cout << "AgentDaemon. Agent Registration failed: " << result << endl;
				#endif
	    		common::DIAgentLogMsg(kuiPhaseA, kuiAgentFeatureID, daemonLogLevel, common::ALERT,common::GENERAL,"Error | ApiRegisterAgent failed: %d. Will retry till success.", result);
	    		isRegistrationStatusLogged = true;
	    	}
		    sleep(5);
	    }

    } while( API_SUCCESS != result );

    return bResult;
}

/*refer declaration*/
static void Run(void)
{
	while (1)
	{
		//if (g_bDoSubscribe && g_stFeaturesStatus.bIsSigChangeStarted)
		if (g_bDoSubscribe && g_stFeaturesStatus.bIsAgentFeatureStarted)
		{
			#ifdef debugDaemon
			cout << "AgentDaemon.Run(). g_bDoSubscribe true" << endl ;
			#endif

			SubscribeToMetrologyData() ;
			g_bDoSubscribe = false ;

			//Make this flag as true to send start up message
			//This msg needs to be sent only after agent is registered successfully
			if (false == gFeatureStatusUpdated )
			{
				gFeatureStatusUpdated = true;
				LogAgentStartupMessage(gStrmEnabledFeatures.str(), gStrmDisabledFeatures.str());
			}
#ifdef FASTSIM 	
			cout << "FastSim Enabled\n";
			if (CCommonMetrology::m_bIsFastSimulationEnabled)
			{
				bool bretCSVRead = CCommonMetrology::ReadMetDataFromCSV();
				cout << "Log:DBG:bretCSVRead:" << bretCSVRead << endl;
			}
#endif			
		}
		sleep(5);
	}
}

static void Finalize(void)
{
	#ifdef debugDaemon
		cout << "AgentDaemon.Finalize()" << endl ;
	#endif

	finalize();  //to stop timer from mytimer.cpp

	g_abPresentStatus[AGENTFEATURE] = false;
	g_abPresentStatus[COMMANDEXECUTION] = false;
	g_abPresentStatus[GENERICFEATURE] = false;
	g_abPresentStatus[CONFIGFEATURE] = false;

	sleep(1);
	UnSubscribeFromMetrologyData();
	CCommonMetrology::GetCommonMetrologyInstance()->ReleaseCommonMetrologyInstance();

    AgentApiReturnType result = apiDeRegisterAgent();
    if(API_SUCCESS == result)
	{
		#ifdef debugDaemon
		cout<<"AgentDaemon.Finalize(). DeRegister Agent Success" << endl;
		#endif
	}
	else
	{
		#ifdef debugDaemon
		cout<<"AgentDaemon.Finalize(). DeRegister Agent Error: " << result << endl;
		#endif
	}
}


/*refer declaration*/
static void SignalHandler(int i_iSigNum)//!OCLINT
{

	#ifdef debugDaemon
	cout << "AgentDaemon.SigHndlr: Signal: " << i_iSigNum << endl ;
	#endif

	//AgentApiReturnType result;

	if(i_iSigNum==SIGUSR1)				// Signal for starting features
	{
		#ifdef debugDaemon
		cout << "AgentDaemon.SignalHandler(). Signal SIGUSR1" << endl ;
		#endif
      //  common::DIAgentLogMsg(kuiSigChangeFeatureID, daemonLogLevel, common::INFO, common::GENERAL,"INFO | received SIGUSR1");
		//update the global variable based on command received
		common::CurrentFeatureList(kbyAllowedNumberOfFeatures, g_abPresentStatus, 
									g_abyOrderOfFeature, kauiAllowedFeatures, kastrFeatureName, kstrCmdFilePath, kstrStatusFilePath);

		bool bIsEnabledFeatureListEmpty = true, bIsDisabledFeatureListEmpty = true;

		//Clean the stream
		gStrmEnabledFeatures.str("");
		gStrmEnabledFeatures.clear();
		gStrmDisabledFeatures.str("");
		gStrmDisabledFeatures.clear() ;
		std::ios::fmtflags f( gStrmEnabledFeatures.flags() );
		gStrmEnabledFeatures << std::hex;
		gStrmDisabledFeatures << std::hex;
		
		if(true == g_abPresentStatus[GENERICFEATURE])
		{
			g_stFeaturesStatus.bIsGenericFeatureStarted = true;
			#ifdef debugDaemon
			cout << "AgentDaemon.SigHndlr: Generic Feature started." << endl;
			#endif

			bIsEnabledFeatureListEmpty = false;
			gStrmEnabledFeatures << kuiGenericFeatureID;
		}
		else
		{
			g_stFeaturesStatus.bIsGenericFeatureStarted = false;
			#ifdef debugDaemon
			cout << "AgentDaemon.SigHndlr: Generic Feature not running." << endl;
			#endif

			bIsDisabledFeatureListEmpty = false;
			gStrmDisabledFeatures << kuiGenericFeatureID;
		}

		if(true == g_abPresentStatus[AGENTFEATURE])
		{
			g_stFeaturesStatus.bIsAgentFeatureStarted = true;
			g_bDoSubscribe = true ;
			CCommonMetrology::GetCommonMetrologyInstance()->SetFeatureUsrSignalStatus(true);
			
			#ifdef debugDaemon
			cout << "AgentDaemon.SigHndlr: Subscribe" << endl ;
			cout << "AgentDaemon.SigHndlr: AgentFeature started." << endl;
			#endif

			if(false == bIsEnabledFeatureListEmpty)	// This is to avoid extra space in the the begining of EnabledFeatureList while sending startup msg
			{
				gStrmEnabledFeatures << " ";
			}
			bIsEnabledFeatureListEmpty = false;
			gStrmEnabledFeatures << kuiAgentFeatureID;
		}
		else
		{
			g_stFeaturesStatus.bIsAgentFeatureStarted = false;
			g_bDoSubscribe = false ;
			CCommonMetrology::GetCommonMetrologyInstance()->SetFeatureUsrSignalStatus(false);

			UnSubscribeFromMetrologyData();

			#ifdef debugDaemon
			cout << "AgentDaemon.SigHndlr: AgentFeature is not running." << endl;
			cout << "AgentDaemon.SigHndlr: Not subscribing to SubscribeToMetrologyData" << endl;
			#endif
			common::DIAgentLogMsg(kuiPhaseA, kuiAgentFeatureID, daemonLogLevel, common::ALERT,common::GENERAL,"AgentDaemon. Not subscribing to SubscribeToMetrologyData");
      		
      		if(false == bIsDisabledFeatureListEmpty)	// This is to avoid extra space in the the begining of DisabledFeatureList while sending startup msg
			{
      			gStrmDisabledFeatures << " ";
			}
			bIsDisabledFeatureListEmpty = false;
			gStrmDisabledFeatures << kuiAgentFeatureID;
      	}

		if(true == g_abPresentStatus[COMMANDEXECUTION])
		{
			g_stFeaturesStatus.bIsCommandExecStarted = true;
			#ifdef debugDaemon
			cout << "AgentDaemon.SigHndlr: Command Execution Feature started." << endl;
			#endif

			if(false == bIsEnabledFeatureListEmpty)	// This is to avoid extra space in the the begining of EnabledFeatureList while sending startup msg
			{
				gStrmEnabledFeatures << " ";
			}
			bIsEnabledFeatureListEmpty = false;
			gStrmEnabledFeatures << kuiCommandConfigFeatureID;
		}
		else
		{
			g_stFeaturesStatus.bIsCommandExecStarted = false;
			#ifdef debugDaemon
			cout << "AgentDaemon.SigHndlr: Command Execution Feature is not running." << endl;
			#endif
			if(false == bIsDisabledFeatureListEmpty)	// This is to avoid extra space in the the begining of DisabledFeatureList while sending startup msg
			{
				gStrmDisabledFeatures << " ";
			}
			bIsDisabledFeatureListEmpty = false;
			gStrmDisabledFeatures << kuiCommandConfigFeatureID;
		}

		if(true == g_abPresentStatus[CONFIGFEATURE])
		{
			g_stFeaturesStatus.bIsConfigFeatureStarted = true;
			#ifdef debugDaemon
			cout << "AgentDaemon.SigHndlr: Config Feature started." << endl;
			#endif

			if(false == bIsEnabledFeatureListEmpty)	// This is to avoid extra space in the the begining of EnabledFeatureList while sending startup msg
			{
				gStrmEnabledFeatures << " ";
			}
			bIsEnabledFeatureListEmpty = false;
			gStrmEnabledFeatures << kuiConfigFeatureID;
		}
		else
		{
			g_stFeaturesStatus.bIsConfigFeatureStarted = false;
			#ifdef debugDaemon
			cout << "AgentDaemon.SigHndlr: Config Feature is not running." << endl;
			#endif
			if(false == bIsDisabledFeatureListEmpty)	// This is to avoid extra space in the the begining of DisabledFeatureList while sending startup msg
			{
				gStrmDisabledFeatures << " ";
			}
			bIsDisabledFeatureListEmpty = false;
			gStrmDisabledFeatures << kuiConfigFeatureID;
		}
		gStrmDisabledFeatures.flags(f);
		gStrmEnabledFeatures.flags(f);

		LogAgentStartupMessage(gStrmEnabledFeatures.str(), gStrmDisabledFeatures.str());
	}
	else if(i_iSigNum==SIGINT)
	{
		#ifdef debugDaemon
		cout << "AgentDaemon.SignalHandler(). Signal SIGINT" << endl ;
		#endif
        common::DIAgentLogMsg(kuiPhaseA, kuiAgentFeatureID, daemonLogLevel, common::INFO,common::GENERAL,"INFO | received SIGINT | Daemon exit now");
        Finalize();
        exit(1);
    }
    else if(i_iSigNum==SIGTERM)
    {
		#ifdef debugDaemon
		cout << "AgentDaemon.SignalHandler(). Signal SIGTERM" << endl ;
		#endif
        common::DIAgentLogMsg(kuiPhaseA, kuiAgentFeatureID, daemonLogLevel, common::INFO,common::GENERAL,"INFO | received SIGTERM | Terminating Daemon");
        Finalize();
        exit(1);
    }
    else if(i_iSigNum==SIGKILL)
    {
		#ifdef debugDaemon
		cout << "AgentDaemon.SignalHandler(). Signal SIGKILL" << endl ;
		#endif
        common::DIAgentLogMsg(kuiPhaseA, kuiAgentFeatureID, daemonLogLevel, common::INFO,common::GENERAL,"INFO | received SIGKILL | Exit Daemon");
        Finalize();
        exit(1);
    }
    else if(i_iSigNum==SIGSEGV)
    {
		common::DIAgentLogMsg(kuiPhaseNA,kuiAgentFeatureID, daemonLogLevel, common::ERR,common::GENERAL,"INFO | received SIGSEGV |Exit Daemon");
		signal(SIGSEGV,SIG_DFL);
		kill(getpid(),i_iSigNum);
		Finalize();
		exit(1);
    }
    else
    {
		#ifdef debugDaemon
		cout << "AgentDaemon.SignalHandler(). Invalid Signal : " << i_iSigNum << endl ;
		#endif
    }
}

string ApiVariableType_GetString(ApiVariableType value)
{
	string str;

	if (value.type == AGENT_API_STRING)
	{
		str.assign(value.value.String.stringPtr, value.value.String.stringLen);
	}
	return str;
}

void LogAgentStartupMessage(const string &i_strEnabledFeatures, const string &i_strDisabledFeatures)
{
    if (false == gFeatureStatusUpdated)
	{
		//Return from the function as Agent registration is incomplete
		cout << "DMN.SAStrtUpMsg. Agt not rdy" << endl;
		return;
	}

    stAgentStartupInfo startupInfo;
	startupInfo.uAgentId = AGENTID;
	startupInfo.uMajorVersion = MAJORVERSION;
	startupInfo.uMinorVersion = MINORVERSION;
	startupInfo.uBuildNum = BUILDNUMBER;
	startupInfo.uMemoryLimit = MEMLIMIT;
	startupInfo.uCPULimit = CPULIMIT;
	startupInfo.uFlashLimit = FLASHLIMIT;

	CCommonDiag objCommonDiag;

	objCommonDiag.SetAgentStartUpInfo(startupInfo);
	objCommonDiag.SendAgentStartupInfoMessage(kuiGenericFeatureID, i_strEnabledFeatures, i_strDisabledFeatures);
}
