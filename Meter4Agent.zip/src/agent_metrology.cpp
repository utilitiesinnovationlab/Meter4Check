////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                         PROPRIETARY RIGHTS NOTICE:                         //
//                                                                            //
//         ALL RIGHTS RESERVED. THIS MATERIAL CONTAINS THE VALUABLE           //
//                      PROPERTIES AND TRADE SECRETS OF                       //
//                                                                            //
//                                 Itron,                                     //
//                           BANGALORE, INDIA                                 //
//                                                                            //
//                  EMBODYING SUBSTANTIAL CREATIVE EFFORTS                    //
//   AND TRADE SECRETS, CONFIDENTIAL INFORMATION, IDEAS AND EXPRESSIONS, NO   //
//    PART OF WHICH MAY BE REPRODUCED OR TRANSMITTED IN ANY FORM OR BY ANY    //
//   MEANS ELECTRONIC, MECHANICAL, OR OTHERWISE, INCLUDING PHOTOCOPYING AND   //
//        RECORDING OR IN CONNECTION WITH ANY INFORMATION STORAGE OR          //
//         RETRIEVAL SYSTEM WITHOUT THE PERMISSION IN WRITING FROM            //
//                                  Itron, Inc.                               //
//                                                                            //
//                                 COPYRIGHT 2016                             //
//                                  Itron. Inc.                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

/*!************************************************************************//**
 * @file          agent_metrology.cpp
 * @brief         Implements metrology interfacing with APP SDK
 * @date          16.Aug.2017
 * @author        Deepika Durgvanshi
 ******************************************************************************/

#include <unistd.h>
#include <iostream>
#include <common.h>
using namespace std;

// Module headers
#include <agent_config.h>
#include <agent_constants.h>
#include <agent_metrology.h>
#include <agent_feature.h>

// Other module headers*/
#include <Itron/AgentApi.h>
#include <apiWrapper.h>
#include <common_metrology.h>

common::ELogLevel metrolLogLevel = kDefaultLogLevel ;
extern bool g_abPresentStatus[] ;

bitMask bmMetLids = 0;

extern CAgentFeature g_objAgentFeature;

//process the metrology data
void ProcessLids(const stMetrologyLids& i_lidData)
{
	#ifdef FASTSIM 
	time_t mnow = time(NULL);
	#endif
	stMetrologyLids stLidData = i_lidData;
	uint64_t ulCount = CCommonMetrology::GetCommonMetrologyInstance()->GetMetCBCount();
	#ifdef agentLevelLog
		cout << "[P:" << (int)kuiPhaseNA << "]" << "-" << ulCount << ".Srt-" << endl ;
	#endif
	if (0 != stLidData.ulTimeStamp)
    {
        stLidData.ulTimeStamp /= 1000;
    }
	#ifdef agentLevelLog
		cout << "MTR.Metrology: [TS,VA,VB,VC,PF,IA,IB,IC,CM,CC]:["
		//cout << "MTR.Metrology: [TS,VA,PF,IA,CM,CC,TA]:["
		//cout << "MTR.Metrology: [TS,VA,PF,IA,]:["
			 << stLidData.ulTimeStamp << ","
			 << stLidData.dVoltageA << ","
			 << stLidData.dVoltageB << ","
			 << stLidData.dVoltageC << ","
			 << stLidData.dLid_INS_POWER_FACTOR << ","
			 << stLidData.dCurrentA << ","
			 << stLidData.dCurrentB << ","
			 << stLidData.dCurrentC << ","
			 << stLidData.dLid_NEUTRAL_CURRENT_MEASURED << ","
			 << stLidData.dLid_NEUTRAL_CURRENT_CALCULATED << "]" << endl;
			 //<< stLidData.dLid_NEUTRAL_CURRENT_TAMPER << "]" << endl;
	#endif
// Call to Agent Specific Feature/Functionility to process metrology Data can go here
	//g_objAgentFeature.checkVoltagestatus(stLidData);
	/*  */
	//g_objAgentFeature.checkCurrentstatus(stLidData);

	//g_objAgentFeature.checkTamperstatus(stLidData);

	g_objAgentFeature.TheftDetection(stLidData);
	
	#ifdef agentLevelLog
		cout << "[P:" << (int)kuiPhaseNA << "]" << "-" << ulCount << ".End-" << endl ;
	#endif

	#ifdef FASTSIM 	
		usleep(1000000 - static_cast<uint32_t>(((time(NULL) - mnow)*1000)));
		//usleep(900 * 1000);
	#endif
}

bool IsAgentFeatureEnabled()
{
	bool bCheckStat = false;
	if (true  ==  g_abPresentStatus[AGENTFEATURE])
	{
		bCheckStat = true;
	}
	else
	{
		common::DIAgentLogMsg(kuiPhaseNA,kuiAgentFeatureID, metrolLogLevel, common::INFO, common::METROLOGY,"MT.VBTFE g_abPresentStatus not TRUE");
	}
	return bCheckStat;
}

// Setup my data subcriptions.
void SubscribeToMetrologyData(void)
{
	CCommonMetrology::GetCommonMetrologyInstance()->RegisterLidProcessor(bmMetLids, IsAgentFeatureEnabled);
}

void UnSubscribeFromMetrologyData()
{
	CCommonMetrology::GetCommonMetrologyInstance()->UnSubscribeFromMetrologyData();
}

void SubscribeLids()
{
	bmMetLids |= INS_VOLTS_A;
	bmMetLids |= INS_VOLTS_B;
	bmMetLids |= INS_VOLTS_C;
	bmMetLids |= INS_POWER_FACTOR;
	bmMetLids |= INS_CURRENT_A;
	bmMetLids |= INS_CURRENT_B;
	bmMetLids |= INS_CURRENT_C;
	//bmMetLids |= NEUTRAL_CURRENT_TAMPER;
	//bmMetLids |= INS_VAB_ANGLE;
	bmMetLids |= NEUTRAL_CURRENT_MEASURED;
	bmMetLids |= NEUTRAL_CURRENT_CALCULATED;
  /*bmMetLids |= INS_VOLTS_B;
	bmMetLids |= INS_VOLTS_C;
	bmMetLids |= INS_CURRENT_A;
	bmMetLids |= INS_CURRENT_B;
	bmMetLids |= INS_CURRENT_C;
	bmMetLids |= INS_W_PHA;
	bmMetLids |= INS_W_PHB;
	bmMetLids |= INS_W_PHC;
	bmMetLids |= INS_VAR_PHA;
	bmMetLids |= INS_VAR_PHB;
	bmMetLids |= INS_VAR_PHC;
	bmMetLids |= INS_VA_PHA;
	bmMetLids |= INS_VA_PHB;
	bmMetLids |= INS_VA_PHC;
	bmMetLids |= INS_FREQUENCY;
	bmMetLids |= INS_VAS_AGGREGATE;
	bmMetLids |= INS_WATTS_AGGREGATE;
	bmMetLids |= INS_VAR_AGGREGATE;
	bmMetLids |= INS_TEMPERATURE_CELCIUS;
	bmMetLids |= INS_POWER_FACTOR;
	bmMetLids |= INS_VAB_ANGLE;
	bmMetLids |= INS_VAC_ANGLE;
	bmMetLids |= NEUTRAL_CURRENT_MEASURED;
	bmMetLids |= NEUTRAL_CURRENT_CALCULATED;
	bmMetLids |= NEUTRAL_CURRENT_TAMPER;
	bmMetLids |= CPC_DATA_INSTLOADVOLTAGEPHA;
	bmMetLids |= CPC_DATA_INSTLOADVOLTAGEPHB;
	bmMetLids |= CPC_DATA_INSTLOADVOLTAGEPHC;
	bmMetLids |= INS_CURRENT_ANGLE_PHA;
	bmMetLids |= INS_CURRENT_ANGLE_PHB;
	bmMetLids |= INS_CURRENT_ANGLE_PHC;*/

}

