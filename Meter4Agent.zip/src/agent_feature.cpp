#include "agent_feature.h"
#include <iostream>
#include <sstream>
#include <stdlib.h>
#include <agent_config.h>
#include <agent_constants.h>
#include <agent_types.h>
#include <data_to_server.h>
using namespace std;
#include <queue>
#include <list>

#include <Itron/AgentApi.h>
#include <common.h>

static const uint32_t kbyAlarmMsgType = 98U;
static const uint32_t kbyCurrentAlarmMsgType = 99U;
static const uint32_t kbyTamperAlarmMsgType = 100U;
static const uint32_t kbyTheftAlarmMsgType = 102U;
static const uint32_t kbyTimeThresold = 300U; // Modified
static const uint32_t kbyMicroTimeThresold = 5U; // Modified
static const uint32_t kbyTimeThresold_PF = 5U; // Modified
static const uint32_t kbyTimeThresoldUpper_Volt = 5U;
static const uint32_t kbyTimeThresoldLower_Volt = 2U;
static const uint32_t kbyVoltageThresoldLower_240V = 220U;
static const uint32_t kbyVoltageThresoldUpper_240V = 230U;
static const uint32_t kbyVoltageThresoldLower_120V = 110U;
static const uint32_t kbyVoltageThresoldUpper_120V = 115U;

CAgentFeature::CAgentFeature()
{
	m_alarmstat = false;
	m_tamperAlarmStat = false;
	m_isAlarmSent  = false;
	m_theftAlarmStat = false;
	m_initialTeftDetection = false;
	m_theftVoltCurrentAlarmStat = false;
    m_theftCurrentDeviationAlarmStat = false;
    m_theftPFCurrentAlarmStat = false;
	cout << "Inside : CAgentFeature  Constructor " <<endl;
	InitializeConfig();
}

CAgentFeature::~CAgentFeature()
{

}

void CAgentFeature::InitializeConfig()
{
	m_genConfig.uiFeatureEnabled = kDefaultFeatureEnabled;
    m_genConfig.uiLogLevel = kDefaultLogLevel;
    m_genConfig.uiKeepLogLevelForSecs = kDefaultKeepLogLevelForSecs;
    m_AgentFeatureConfig.VoltThreshold = static_cast<uint16_t>(kDefaultVBelowThreshold);
    m_AgentFeatureConfig.CheckForVoltage = kDefaultCheckForVolt;
	
	m_AgentFeatureConfig.CurrentThreshold = static_cast<uint32_t>(kDefaultCBelowThreshold);
    m_AgentFeatureConfig.CheckForCurrent = kDefaultCheckForCurrent;

	m_AgentFeatureConfig.TamperThreshold = static_cast<uint32_t>(kDefaultTBelowThreshold);
    m_AgentFeatureConfig.CheckForTamper = kDefaultCheckForTamper;
	m_Power = 0.0;
	m_dblavgCurrent_A = 0.0;
    m_dblavgCurrent_B = 0.0;
    m_dblavgCurrent_C = 0.0;
    m_dblavgVoltage_A = 0.0;
    m_dblavgVoltage_B = 0.0;
    m_dblavgVoltage_C = 0.0;
	m_dblPFactorAvg = 0.0;
	m_theftPFCounter1 = 0;
	m_theftPFCounter2 = 0;
	m_theftVoltCounter1 = 0;
	m_theftVoltCounter2 = 0;
	m_theftVoltCounter3 = 0;
	m_theftVoltCounter4 = 0;
	m_theftPower = 0.0;
	addTime = 0;
}

void CAgentFeature::UpdateAgentFeatureConfig(const stGeneralConfig i_GenConfig, const stAgentFeatureConfig  i_AgentFeatureConfig)
{
	m_genConfig = i_GenConfig;
	m_AgentFeatureConfig = i_AgentFeatureConfig;

	#ifdef debugAgentFeature
	cout << "CAgentFeature::UpdateAgentFeatureConfig(): " << (int)m_genConfig.uiFeatureEnabled << " "
															<< (int)m_genConfig.uiLogLevel << " "
															<< (int)m_genConfig.uiKeepLogLevelForSecs <<" "
															<< (int)m_AgentFeatureConfig.VoltThreshold << " "
															<< (int)m_AgentFeatureConfig.CheckForVoltage << " "
															<< (int)m_AgentFeatureConfig.CurrentThreshold << " "
															<< (int)m_AgentFeatureConfig.CheckForCurrent <<" "
															<< (int)m_AgentFeatureConfig.TamperThreshold << " "
															<< (int)m_AgentFeatureConfig.CheckForTamper <<endl;
	#endif

	DIAgentLogMsg(kuiPhaseA,kuiAgentFeatureID,m_genConfig.uiLogLevel,common::DEBUG,common::DATABASE,"Agent:CAgentFeature::UpdateAgentFeatureConfig(): Config updated.");
}

void CAgentFeature::checkVoltagestatus(const stMetrologyLids& i_stMetData)
{
	cout << " CAgentFeature:: checkVoltagestatus " << endl;

	double dVoltageReading = i_stMetData.dVoltageA ;

	if(m_AgentFeatureConfig.CheckForVoltage &&  m_genConfig.uiFeatureEnabled)
    {
		if (dVoltageReading < m_AgentFeatureConfig.VoltThreshold && m_alarmstat == false)
		{
			m_alarmstat = true;
			sendAlarm(i_stMetData);
		}
		else if (dVoltageReading > m_AgentFeatureConfig.VoltThreshold && m_alarmstat == true)
		{
			m_alarmstat = false;
			sendAlarm(i_stMetData);
		}
	} 
}


void CAgentFeature::sendAlarm(const stMetrologyLids& i_stMetData)
{

    cout << "Inside : CAgentFeature  Send Alarm()" <<endl;
	std::ostringstream stringStream;
	std::string outputString = "";
	stringStream << (int)kbyAlarmMsgType;
	if(true == m_alarmstat )
	{
		stringStream << common::MsgSeparator << "OPEN" ;
	}
	else
	{
		stringStream << common::MsgSeparator << "CLOSE" ;
	}
	stringStream << common::MsgSeparator << i_stMetData.dVoltageA << common::MsgSeparator << i_stMetData.dCurrentA;
	outputString = stringStream.str();
    cout << "outputString: " << outputString << endl;
	CDataToServer::GetDataToServerInstance()->SENDEVENTTOSERVER(kuiAgentFeatureID, outputString.c_str(),static_cast<uint32_t>(outputString.length()),1 , true, i_stMetData.ulTimeStamp );

}

void CAgentFeature::checkCurrentstatus(const stMetrologyLids& i_stMetData)
{
	cout << " CAgentFeature:: checkCurrentstatus " << endl;

	double dCurrentReading = i_stMetData.dCurrentA ;
	
	if(m_AgentFeatureConfig.CheckForCurrent &&  m_genConfig.uiFeatureEnabled)
    {
		if (dCurrentReading < m_AgentFeatureConfig.CurrentThreshold && m_alarmstat == false)
		{
			m_alarmstat = true;
			sendCurrentAlarm(i_stMetData);
		}
		else if (dCurrentReading > m_AgentFeatureConfig.CurrentThreshold && m_alarmstat == true)
		{
			m_alarmstat = false;
			sendCurrentAlarm(i_stMetData);
		}
	}
}

void CAgentFeature::sendCurrentAlarm(const stMetrologyLids& i_stMetData)
{
    cout << "Inside : CAgentFeature  Send Alarm()" <<endl;
	std::ostringstream stringStream;
	std::string outputString = "";
	stringStream << (int)kbyCurrentAlarmMsgType;
	if(true == m_alarmstat )
	{
		stringStream << common::MsgSeparator << "OPEN1" ;
	}
	else
	{
		stringStream << common::MsgSeparator << "CLOSE1" ;
	}
	stringStream << common::MsgSeparator << i_stMetData.dCurrentA;
	outputString = stringStream.str();
    cout << "outputString: " << outputString << endl;
	CDataToServer::GetDataToServerInstance()->SENDEVENTTOSERVER(kuiAgentFeatureID, outputString.c_str(),static_cast<uint32_t>(outputString.length()),1 , true, i_stMetData.ulTimeStamp );

}
void CAgentFeature::checkTamperstatus(const stMetrologyLids& i_stMetData)
{
    	cout << " CAgentFeature:: checkTamperstatus " << endl;

	double dMeasured = i_stMetData.dLid_NEUTRAL_CURRENT_MEASURED;
	double dCalculated = i_stMetData.dLid_NEUTRAL_CURRENT_CALCULATED ;
	
	//sendTamperAlarm(i_stMetData);

	//if(m_AgentFeatureConfig.CheckForTamper &&  m_genConfig.uiFeatureEnabled)
	if(m_genConfig.uiFeatureEnabled)
    {
		//sendTamperAlarm(i_stMetData);
		double currentDiffPercentage = ((dCalculated - dMeasured)/dCalculated)*100;
		
		if (currentDiffPercentage > kuiMinDiffPercentage  && m_tamperAlarmStat == false)
		{
			m_tamperAlarmStat = true;
			m_tamperStartTime = i_stMetData.ulTimeStamp;
			m_Power += i_stMetData.dVoltageA * (dCalculated - dMeasured) * i_stMetData.dLid_INS_POWER_FACTOR;
			cout << "Tamper Started at" << m_tamperStartTime << " with dLid_NEUTRAL_CURRENT_CALCULATED:" 
			<< dCalculated << " "
			<< "dLid_NEUTRAL_CURRENT_MEASURED: "
			<< dMeasured << " "
			<<endl;
		}
		else if(currentDiffPercentage > kuiMinDiffPercentage){
			m_tamperAlarmStat = true;
			m_Power += i_stMetData.dVoltageA * (dCalculated - dMeasured) * i_stMetData.dLid_INS_POWER_FACTOR;
			if(i_stMetData.ulTimeStamp - m_tamperStartTime >= kuiMinDiffInterval && m_isAlarmSent == false){
				m_isAlarmSent = true;
				m_eventID = m_tamperStartTime;
				sendTamperAlarm(i_stMetData);
			}
			cout << "Tamper continue with dLid_NEUTRAL_CURRENT_CALCULATED:" 
			<< dCalculated << " "
			<< "dLid_NEUTRAL_CURRENT_MEASURED: "
			<< dMeasured << " "
			<<endl; 
		}
		else if(currentDiffPercentage <= kuiMinDiffPercentage && m_tamperAlarmStat == true){
			m_tamperAlarmStat = false;
			uint64_t timmdiff = i_stMetData.ulTimeStamp - m_tamperStartTime;
			m_Power += i_stMetData.dVoltageA * (dCalculated - dMeasured) * i_stMetData.dLid_INS_POWER_FACTOR;
			cout << "TimeDiff check:" << timmdiff;
			if(timmdiff >= kuiMinDiffInterval){
				sendTamperAlarm(i_stMetData);
				m_isAlarmSent = false;
				//uint64_t timmdiff = i_stMetData.ulTimeStamp - m_tamperStartTime - kuiMinDiffInterval;
				cout << "Tamper close event after " << timmdiff - kuiMinDiffInterval
				<< " seconds dLid_NEUTRAL_CURRENT_CALCULATED:" 
				<< dCalculated << " "
				<< "dLid_NEUTRAL_CURRENT_MEASURED: "
				<< dMeasured 
				<<endl;
				m_Power = 0;
				m_eventID = 0;
			}
			else{
				cout << "Tamper closed without theft event because dLid_NEUTRAL_CURRENT_CALCULATED:" 
				<< dCalculated << " "
				<< "dLid_NEUTRAL_CURRENT_MEASURED: "
				<< dMeasured << " is within threasol level"
				<<endl;
			}
		}		
	}
}

void CAgentFeature::sendTamperAlarm(const stMetrologyLids& i_stMetData)
{
    cout << "Inside : CAgentFeature  Send Alarm()" <<endl;
	std::ostringstream stringStream;
	std::string outputString = "";
	stringStream << (int)kbyTamperAlarmMsgType;
	if(true == m_tamperAlarmStat )
	{
		stringStream << common::MsgSeparator << "Tamper OPEN" << common::MsgSeparator << 0;
	}
	else
	{
		uint64_t timmdiff = i_stMetData.ulTimeStamp - m_tamperStartTime - kuiMinDiffInterval;
		stringStream << common::MsgSeparator << "Tamper CLOSE" << common::MsgSeparator << timmdiff;
	}

	
	stringStream 
				<< common::MsgSeparator << i_stMetData.dVoltageA
				<< common::MsgSeparator << i_stMetData.dCurrentA 
				<< common::MsgSeparator << i_stMetData.dLid_INS_POWER_FACTOR
				<< common::MsgSeparator << i_stMetData.dLid_NEUTRAL_CURRENT_MEASURED 
				<< common::MsgSeparator << i_stMetData.dLid_NEUTRAL_CURRENT_CALCULATED
				<< common::MsgSeparator << m_Power
				<< common::MsgSeparator << m_eventID;
	outputString = stringStream.str();
    cout << "outputString: " << outputString << endl;
	CDataToServer::GetDataToServerInstance()->SENDEVENTTOSERVER(kuiAgentFeatureID, outputString.c_str(),static_cast<uint32_t>(outputString.length()),1 , true, i_stMetData.ulTimeStamp );

}

void CAgentFeature::TheftDetection(const stMetrologyLids& i_stMetData){
	cout << "in side TheftDetection" << endl;
	elecParam avgParam, avgParamMicro;
	elecParam tempParam;
	tempParam.m_dblVoltage_A = i_stMetData.dVoltageA;
	tempParam.m_dblVoltage_B = i_stMetData.dVoltageB;
	tempParam.m_dblVoltage_C = i_stMetData.dVoltageC;
	tempParam.m_dblCurrent_A = i_stMetData.dCurrentA;
    tempParam.m_dblCurrent_B = i_stMetData.dCurrentB;
    tempParam.m_dblCurrent_C = i_stMetData.dCurrentC;
    tempParam.m_dblPFactor = i_stMetData.dLid_INS_POWER_FACTOR;
	if(m_elecParam.size() > 0){
		int size = kbyTimeThresold;
		//cout << "size: " << size << endl;
		avgParam = AvgCalculation(size);
		//cout << "avgParam.m_dblPFactor: " << avgParam.m_dblPFactor << endl;
		size = kbyMicroTimeThresold;
		//cout << "minor.size: " << size << endl;
		avgParamMicro = AvgCalculation(size);
		//cout << "avgParamMicro.m_dblPFactor: " << avgParamMicro.m_dblPFactor << endl;
	}
	if(m_elecParam.size() < kbyTimeThresold){
		m_elecParam.push_back(tempParam);
	} else{
		m_elecParam.pop_front();
		m_elecParam.push_back(tempParam);
	}

	if(m_elecParam.size() == kbyTimeThresold){
		int res = 4;//initial value
		double diff = 0;
		int currentVoltDeviRes = CheckCurrentVoltageDeviationforTheft(i_stMetData, avgParam, avgParamMicro);
		int currentPFDeviRes = CheckPFactorDeviationforTheft(i_stMetData, avgParam);
		if(CheckSupplyVoltage(i_stMetData)){ // 240V
			cout << "240V" << endl;
			diff  = CheckCurrentDeviationforTheft(i_stMetData); 
			res = diff > 1.0 || currentVoltDeviRes || currentPFDeviRes;
			//MakeDecission(i_stMetData, res, diff);
		} else { // 120V
				res = currentVoltDeviRes || currentPFDeviRes;
				cout << "120V" << endl;
				//MakeDecission(i_stMetData, res, diff);
			}	
		cout << "TheftDetection.res: " << res << endl;
		if(res != 4 && (res == 1 || res == 0)){
			MakeDecission(i_stMetData, res, diff);
		}
	}
}
void CAgentFeature::sendTheftAlarm(const stMetrologyLids& i_stMetData)
{
	cout << "Inside : CAgentFeature  Send Theft Alarm()" <<endl;
	std::ostringstream stringStream;
	std::string outputString = "";   
	stringStream << (int)kbyTheftAlarmMsgType;
	if(true == m_theftAlarmStat )  //Line Modified By PS
	{
		stringStream << common::MsgSeparator << "Theft OPEN" << common::MsgSeparator << 0;
	}
	else
	{
		uint64_t timmediff = i_stMetData.ulTimeStamp - m_theftStartTime + addTime;    //Line Modified  by PS;
		stringStream << common::MsgSeparator << "Theft CLOSE" << common::MsgSeparator << timmediff;
	}
	stringStream 
				<< common::MsgSeparator << i_stMetData.dVoltageA //<<","<< i_stMetData.dVoltageB <<","<< i_stMetData.dVoltageC
				<< common::MsgSeparator << i_stMetData.dCurrentA //<<","<< i_stMetData.dCurrentB <<","<< i_stMetData.dCurrentC
				<< common::MsgSeparator << i_stMetData.dLid_INS_POWER_FACTOR
				<< common::MsgSeparator << i_stMetData.dLid_NEUTRAL_CURRENT_MEASURED 
				<< common::MsgSeparator << i_stMetData.dLid_NEUTRAL_CURRENT_CALCULATED
				<< common::MsgSeparator << m_Power
				<< common::MsgSeparator << m_theftStartTime; // added by PS
	outputString = stringStream.str();
    cout << "outputString: " << outputString << endl;
	CDataToServer::GetDataToServerInstance()->SENDEVENTTOSERVER(kuiAgentFeatureID, outputString.c_str(),static_cast<uint32_t>(outputString.length()),1 , true, i_stMetData.ulTimeStamp );
}

CAgentFeature::elecParam CAgentFeature::AvgCalculation(int size){
	elecParam avgParam;
	double dblVoltageSum_A = 0.0;
	double dblVoltageSum_B = 0.0;
	double dblVoltageSum_C = 0.0;
	double dblCurrentSum_A = 0.0;
	double dblCurrentSum_B = 0.0;
	double dblCurrentSum_C = 0.0;
	double dblPFactorSum = 0.0;
	int count = 0;
	list<elecParam>::iterator l_iter;
	for(l_iter = m_elecParam.begin(); (l_iter !=m_elecParam.end()); l_iter++, count++){
		elecParam temp = *l_iter;
		//cout << "temp.m_dblPFactor: " << temp.m_dblPFactor << endl;
		//cout << "dblPFactorSum: " << dblPFactorSum << endl;
		if(int(m_elecParam.size()) > size && int(m_elecParam.size()) - count > size){
			continue;
		} else{
			dblVoltageSum_A += temp.m_dblVoltage_A;
			dblVoltageSum_B += temp.m_dblVoltage_B;
			dblVoltageSum_C += temp.m_dblVoltage_C;
			dblCurrentSum_A += temp.m_dblCurrent_A;
			dblCurrentSum_B += temp.m_dblCurrent_B;
			dblCurrentSum_C += temp.m_dblCurrent_C;
			dblPFactorSum += temp.m_dblPFactor;
		}
	}
	//cout << "dblPFactorSum: " << dblPFactorSum << endl;
	avgParam.m_dblVoltage_A = dblVoltageSum_A/size;
	avgParam.m_dblVoltage_B = dblVoltageSum_B/size;
	avgParam.m_dblVoltage_C = dblVoltageSum_C/size;
	avgParam.m_dblCurrent_A = dblCurrentSum_A/size;
    avgParam.m_dblCurrent_B = dblCurrentSum_B/size;
    avgParam.m_dblCurrent_C = dblCurrentSum_C/size;
    avgParam.m_dblPFactor = dblPFactorSum/size;
	//cout
	//cout << "avgParam.m_dblPFactor: " << avgParam.m_dblPFactor << endl;
	return avgParam;
}
int CAgentFeature::CheckSupplyVoltage(const stMetrologyLids& i_stMetData){
	double dblVoltage_A = i_stMetData.dVoltageA;
	double dblVoltage_B = i_stMetData.dVoltageB;
	double dblVoltage_C = i_stMetData.dVoltageC;
	int res = 0; // 120V supply
	if ((dblVoltage_A != 0.0 && dblVoltage_B != 0.0 && dblVoltage_C == 0.0)
		|| (dblVoltage_B != 0.0 && dblVoltage_C != 0.0 && dblVoltage_A == 0.0)
		|| (dblVoltage_C != 0.0 && dblVoltage_A != 0.0 && dblVoltage_B == 0.0))
	{
		res = 1; // 240V supply
	}
	cout << "CheckSupplyVoltage.result: " << res << endl; 
	return res;
}

double CAgentFeature::CheckCurrentDeviationforTheft(const stMetrologyLids& i_stMetData){
	double dblVoltage_A = i_stMetData.dVoltageA;
	double dblVoltage_B = i_stMetData.dVoltageB;
	double dblVoltage_C = i_stMetData.dVoltageC;
	double dblCurrent_A = i_stMetData.dCurrentA;
    double dblCurrent_B = i_stMetData.dCurrentB;
    double dblCurrent_C = i_stMetData.dCurrentC;
	double dblPF = i_stMetData.dLid_INS_POWER_FACTOR;
	double diff = 0;
	if(dblCurrent_A != 0.0 && dblCurrent_B != 0.0){
		diff = dblCurrent_A > dblCurrent_B ? dblCurrent_A - dblCurrent_B : dblCurrent_B - dblCurrent_A;
		PowerCalculation(dblVoltage_A, dblCurrent_A, dblVoltage_B, dblCurrent_B, dblPF);
	}
	else if(dblCurrent_B != 0.0 && dblCurrent_C != 0.0){
		diff = dblCurrent_B > dblCurrent_C ? dblCurrent_B - dblCurrent_C : dblCurrent_C - dblCurrent_B;
		PowerCalculation(dblVoltage_B, dblCurrent_B, dblVoltage_C, dblCurrent_C, dblPF);
	}
	else{
		diff = dblCurrent_A > dblCurrent_C ? dblCurrent_A - dblCurrent_C : dblCurrent_C - dblCurrent_A;
		PowerCalculation(dblVoltage_C, dblCurrent_C, dblVoltage_A, dblCurrent_A, dblPF);
	}
	int result = diff > 1 ? 1 : 0;
	cout << "CheckCurrentDeviationforTheft.diff: "<< diff << endl;
	cout << "CheckCurrentDeviationforTheft.result: "<< result << endl;
	return diff;
}

void CAgentFeature::PowerCalculation(double dblVoltageA, double dblCurrentA, double dblVoltageB, double dblCurrentB, double dblPF){
	m_theftPower = ((dblVoltageA * dblCurrentA) - (dblVoltageB * dblCurrentB)) * dblPF;
	m_theftPower = m_theftPower > 0 ? m_theftPower : -m_theftPower;
}

int CAgentFeature::CheckPFactorDeviationforTheft(const stMetrologyLids& i_stMetData, elecParam& avgParam){
	double dblPFactor = i_stMetData.dLid_INS_POWER_FACTOR;
	double dblCurrent_A = i_stMetData.dCurrentA;
    double dblCurrent_B = i_stMetData.dCurrentB;
    double dblCurrent_C = i_stMetData.dCurrentC;
	int result = 0;
	/*cout << "CheckPFactorDeviationforTheft" << endl;
	cout << "dblPFactor: " << dblPFactor << endl;
	cout << "dblCurrent_A: " << dblCurrent_A << endl;
	cout << "dblCurrent_B: " << dblCurrent_B << endl;
	cout << "avgParam.m_dblPFactor: " << avgParam.m_dblPFactor << endl;
	cout << "avgParam.m_dblCurrent_A: " << avgParam.m_dblCurrent_A << endl;
	cout << "avgParam.m_dblCurrent_B: " << avgParam.m_dblCurrent_B << endl;*/
	// below logic is for 240V supply 
	if(dblCurrent_A != 0 && dblCurrent_B != 0 && dblCurrent_C == 0){
		if(dblPFactor < avgParam.m_dblPFactor 
			&& dblCurrent_A <= avgParam.m_dblCurrent_A 
			&& dblCurrent_B <= avgParam.m_dblCurrent_B){
				result = 1;
		}
	}
	else if(dblCurrent_B != 0 && dblCurrent_C != 0 && dblCurrent_A == 0){
		if(dblPFactor < avgParam.m_dblPFactor 
			&& dblCurrent_B <= avgParam.m_dblCurrent_B 
			&& dblCurrent_C <= avgParam.m_dblCurrent_C){
				result = 1;
		}		
	}
	else if(dblCurrent_A != 0 && dblCurrent_C != 0 && dblCurrent_B == 0){
		if(dblPFactor < avgParam.m_dblPFactor 
			&& dblCurrent_A <= avgParam.m_dblCurrent_A 
			&& dblCurrent_C <= avgParam.m_dblCurrent_C){
				result = 1;
		}		
	}
	// below logic is for 120V supply
	if(dblCurrent_B == 0 && dblCurrent_C == 0){
		if(dblPFactor < avgParam.m_dblPFactor 
			&& dblCurrent_A <= avgParam.m_dblCurrent_A){
				result = 2;
		}
	}
	else if(dblCurrent_A == 0 && dblCurrent_C == 0){
		if(dblPFactor < avgParam.m_dblPFactor 
			&& dblCurrent_B <= avgParam.m_dblCurrent_B){
				result = 2;
		}		
	}
	else if(dblCurrent_A == 0 && dblCurrent_B == 0){
		if(dblPFactor < avgParam.m_dblPFactor
			&& dblCurrent_C <= avgParam.m_dblCurrent_C){
				result = 2;
		}		
	}
	cout << "CheckPFactorDeviationforTheft.result: "<< result << endl;
	switch (result)
	{
	case 1: m_theftPFCounter1 += 1;
			m_theftPFCounter2 = 0;
		break;
	case 2: m_theftPFCounter1 = 0;
			m_theftPFCounter2 += 1;
		break;
	
	default: m_theftPFCounter1 = 0;
			m_theftPFCounter2 = 0;
		break;
	}
	return result;
}

int CAgentFeature::CheckCurrentVoltageDeviationforTheft(const stMetrologyLids& i_stMetData, elecParam& avgParam, elecParam& avgParamMicro){
	cout << "CheckCurrentVoltageDeviationforTheft" << endl;
	double dblCurrent_A = i_stMetData.dCurrentA;
    double dblCurrent_B = i_stMetData.dCurrentB;
    double dblCurrent_C = i_stMetData.dCurrentC;
	double dblVoltage_A = i_stMetData.dVoltageA;
	double dblVoltage_B = i_stMetData.dVoltageB;
	double dblVoltage_C = i_stMetData.dVoltageC;
	double diff = 0.0;
	int result = 0;
	//cout << "dblPFactor: " << dblPFactor << endl;
	//cout << "dblCurrent_A: " << dblCurrent_A << endl;
	//cout << "dblCurrent_B: " << dblCurrent_B << endl;
	//cout << "avgParam.m_dblPFactor: " << avgParam.m_dblPFactor << endl;
	//cout << "avgParam.m_dblCurrent_A: " << avgParam.m_dblCurrent_A << endl;
	//cout << "avgParamMicro.m_dblC/urrent_A: " << avgParamMicro.m_dblCurrent_A << endl;
	//cout << "avgParam.m_dblCurrent_B: " << avgParam.m_dblCurrent_B << endl;*/
	// below logic is for 240V supply 
	if(dblVoltage_A != 0.0){
		if(avgParam.m_dblCurrent_A == 0.0 || avgParam.m_dblCurrent_A < 10.0){
			m_initialTeftDetection = true;
		}
	}
	if(dblVoltage_B != 0.0){
		if(avgParam.m_dblCurrent_B == 0.0 || avgParam.m_dblCurrent_B < 10.0){
			m_initialTeftDetection = true;
		}
	}
	if(dblVoltage_C != 0.0){
		if(avgParam.m_dblCurrent_C == 0.0 || avgParam.m_dblCurrent_C < 10.0){
			m_initialTeftDetection = true;
		}
	}
	if(dblCurrent_A != 0.0 && dblCurrent_B != 0.0 && dblCurrent_C == 0.0){
		diff = dblVoltage_A > dblVoltage_B ? dblVoltage_A - dblVoltage_B : dblVoltage_B - dblVoltage_A;
		if(diff < double(kbyVoltageThresoldUpper_240V) && diff >= double(kbyVoltageThresoldLower_240V) 
			&& dblCurrent_A <= avgParam.m_dblCurrent_A 
			&& dblCurrent_B <= avgParam.m_dblCurrent_B){
				result = 1;
			}
		else if(diff < double(kbyVoltageThresoldLower_240V)
				&& dblCurrent_A <= avgParamMicro.m_dblCurrent_A 
				&& dblCurrent_B <= avgParamMicro.m_dblCurrent_B){
					result = 2;
			}
	}
	else if(dblCurrent_B != 0.0 && dblCurrent_C != 0.0 && dblCurrent_A == 0.0){
		diff = dblVoltage_B > dblVoltage_C ? dblVoltage_B - dblVoltage_C : dblVoltage_C - dblVoltage_B;
		if(diff < double(kbyVoltageThresoldUpper_240V) && diff >= double(kbyVoltageThresoldLower_240V) 
			&& dblCurrent_B <= avgParam.m_dblCurrent_B 
			&& dblCurrent_C <= avgParam.m_dblCurrent_C){
				result = 1; //
		}
		else if(diff < double(kbyVoltageThresoldLower_240V) 
				&& dblCurrent_B <= avgParamMicro.m_dblCurrent_B 
				&& dblCurrent_C <= avgParamMicro.m_dblCurrent_C){
					result = 2;
		}
	}
	else if(dblCurrent_C != 0.0 && dblCurrent_A != 0.0 && dblCurrent_B == 0.0){
		diff = dblVoltage_C > dblVoltage_A ? dblVoltage_C - dblVoltage_A : dblVoltage_A - dblVoltage_C;
		if(diff < double(kbyVoltageThresoldUpper_240V) && diff >= double(kbyVoltageThresoldLower_240V) 
			&& dblCurrent_A <= avgParam.m_dblCurrent_A 
			&& dblCurrent_C <= avgParam.m_dblCurrent_C){
				result = 1;
		}
		else if(diff < double(kbyVoltageThresoldLower_240V) 
				&& dblCurrent_A <= avgParamMicro.m_dblCurrent_A 
				&& dblCurrent_C <= avgParamMicro.m_dblCurrent_C){
					result = 2;
		}
	}

	// below logic is for 120V supply
	if(dblCurrent_B == 0.0 && dblCurrent_C == 0.0){
		diff = dblVoltage_A > 0 ? dblVoltage_A : -dblVoltage_A;
		if(diff < double(kbyVoltageThresoldUpper_120V) && diff >= double(kbyVoltageThresoldLower_120V) 
			&& dblCurrent_A <= avgParam.m_dblCurrent_A){
				result = 3;
			}
		if(diff < double(kbyVoltageThresoldLower_120V) 
				&& dblCurrent_A <= avgParamMicro.m_dblCurrent_A){
					result = 4;
			}
	}
	if(dblCurrent_C == 0 && dblCurrent_A == 0){
		diff = dblVoltage_B > 0 ? dblVoltage_B : -dblVoltage_B;
		if(diff < double(kbyVoltageThresoldUpper_120V) && diff >= double(kbyVoltageThresoldLower_120V) 
			&& dblCurrent_B <= avgParam.m_dblCurrent_B){
				result = 3;
			}
		if(diff < double(kbyVoltageThresoldLower_120V) 
				&& dblCurrent_B <= avgParamMicro.m_dblCurrent_B){
					result = 4;
			}
	}
	if(dblCurrent_A == 0 && dblCurrent_B == 0){
		diff = dblVoltage_C > 0 ? dblVoltage_C : -dblVoltage_C;
		if(diff < double(kbyVoltageThresoldUpper_120V) && diff >= double(kbyVoltageThresoldLower_120V) 
			&& dblCurrent_C <= avgParam.m_dblCurrent_C){
				result = 3;
			}
		else if(diff < double(kbyVoltageThresoldLower_120V) 
				&& dblCurrent_C <= avgParamMicro.m_dblCurrent_C){
					result = 4;
			}
	}
	cout << "CheckCurrentVoltageDeviationforTheft.result: "<< result << endl;
	switch (result)
	{
	case 1: m_theftVoltCounter1 += 1;
			m_theftVoltCounter2 = m_theftVoltCounter2;
			m_theftVoltCounter3 = m_theftVoltCounter3;
			m_theftVoltCounter4 = m_theftVoltCounter4;
			m_initialTeftDetection = m_initialTeftDetection;
		break;
	case 2: m_theftVoltCounter1 = m_theftVoltCounter1;
			m_theftVoltCounter2 += 1;
			m_theftVoltCounter3 = m_theftVoltCounter2;
			m_theftVoltCounter4 = m_theftVoltCounter3;
			m_initialTeftDetection = m_initialTeftDetection;
		break;
	case 3: m_theftVoltCounter1 = m_theftVoltCounter1;
			m_theftVoltCounter2 = m_theftVoltCounter2;
			m_theftVoltCounter3 += 1;
			m_theftVoltCounter4 = m_theftVoltCounter4;
			m_initialTeftDetection = m_initialTeftDetection;
		break;
	case 4: m_theftVoltCounter1 = m_theftVoltCounter1;
			m_theftVoltCounter2 = m_theftVoltCounter2;
			m_theftVoltCounter3 = m_theftVoltCounter3;
			m_theftVoltCounter4 += 1;
			m_initialTeftDetection = m_initialTeftDetection;
		break;
	default: m_theftVoltCounter1 = 0;
			m_theftVoltCounter2 = 0;
			m_theftVoltCounter3 = 0;
			m_theftVoltCounter4 = 0;
			m_initialTeftDetection = false;
		break;
	}
	return result;
}
void CAgentFeature::MakeDecission(const stMetrologyLids& i_stMetData, int res, double diff){
	double dblVoltage = 0;
	// question: which voltage should we take for the power calculation
	cout << "m_initialTeftDetection: " << m_initialTeftDetection << endl;
	cout << "m_theftVoltCounter1: " << m_theftVoltCounter1 << endl;
	cout << "m_theftVoltCounter2: " << m_theftVoltCounter2 << endl;
	cout << "m_theftVoltCounter3: " << m_theftVoltCounter3 << endl;
	cout << "m_theftVoltCounter4: " << m_theftVoltCounter4 << endl;
	cout << "m_theftPFCounter1: " << m_theftPFCounter1 << endl;
	cout << "m_theftPFCounter2: " << m_theftPFCounter2 << endl;
	cout << "m_theftPower: " << m_theftPower << endl;
	cout << "m_Power: " << m_Power << endl;
	int tempRes = m_initialTeftDetection == true
				  || m_theftVoltCounter1 >= int(kbyTimeThresoldUpper_Volt) || m_theftVoltCounter2 >= int(kbyTimeThresoldLower_Volt) 
				  || m_theftVoltCounter3 >= int(kbyTimeThresoldUpper_Volt) || m_theftVoltCounter4 >= int(kbyTimeThresoldLower_Volt) 
				  || m_theftPFCounter1 >= int(kbyTimeThresold_PF) 
				  || m_theftPFCounter2 >= int(kbyTimeThresold_PF);
	
	if(tempRes == 1 && m_theftAlarmStat == false) // alarm start
	{
		cout << "Alarm start" << endl;
		//m_Power += dblVoltage * diff * i_stMetData.dLid_INS_POWER_FACTOR;
		m_Power = 0;
		m_Power = m_theftPower;
		cout << "Power Value:" <<m_Power<< endl;
		m_theftAlarmStat = true;
		m_theftStartTime = i_stMetData.ulTimeStamp;
		sendTheftAlarm(i_stMetData);
		if(m_theftVoltCounter1 >= int(kbyTimeThresoldUpper_Volt) || m_theftVoltCounter3 >= int(kbyTimeThresoldUpper_Volt)){
			addTime = kbyTimeThresoldUpper_Volt - 1U;
		} else if(m_theftVoltCounter2 >= int(kbyTimeThresoldLower_Volt) || m_theftVoltCounter4 >= int(kbyTimeThresoldLower_Volt)){
			addTime = kbyTimeThresoldLower_Volt - 1U;
		} else if(m_theftPFCounter1 >= int(kbyTimeThresold_PF) || m_theftPFCounter2 >= int(kbyTimeThresold_PF)){
			addTime = kbyTimeThresold_PF - 1U;
		}
	} else if(tempRes == 1 && m_theftAlarmStat == true ){// continuous
		cout << "Alarm continue" << endl;
		//m_Power += dblVoltage * diff * i_stMetData.dLid_INS_POWER_FACTOR;
		m_Power += m_theftPower;
		cout << "Power Value:" <<m_Power<< endl;
		m_theftAlarmStat = true;
	} else if (tempRes == 0 && m_theftAlarmStat == true){ // alarm off
	cout << "Alarm stop" << endl;
	m_theftAlarmStat = false; 
		cout << "addTime: " << addTime << endl;
		uint64_t timmediff = i_stMetData.ulTimeStamp - m_theftStartTime + addTime;
		cout << "timmediff: " << timmediff << endl;
			if(timmediff>=theftTimeDiffTH){
								//m_Power += dblVoltage * diff * i_stMetData.dLid_INS_POWER_FACTOR; 
								m_Power += m_theftPower;
								sendTheftAlarm(i_stMetData);
								m_Power = 0; // added by Nilanjan  
								m_theftVoltCounter1 = 0; 
								m_theftVoltCounter2 = 0;
								m_theftVoltCounter3 = 0;
								m_theftVoltCounter4 = 0;
								m_initialTeftDetection = false;
								m_theftPFCounter1 = 0;
								m_theftPFCounter2 = 0;
								addTime = 0;
								cout << "Power Value:" <<m_Power<< endl;
							}
			else{
				cout<< "No Appropiate Theft Detected" <<endl;
				}
	} else{							//default
	//	m_Power += dblVoltage * diff * i_stMetData.dLid_INS_POWER_FACTOR;
		m_theftAlarmStat = false;
		m_Power = 0; 
		/*m_theftVoltCounter1 = 0;  
		m_theftVoltCounter2 = 0;
		m_theftVoltCounter3 = 0;
		m_theftVoltCounter4 = 0;
		m_initialTeftDetection = false;
		m_theftPFCounter1 = 0;
		m_theftPFCounter2 = 0; */ 
	}
}