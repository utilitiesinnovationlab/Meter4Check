////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                         PROPRIETARY RIGHTS NOTICE:                         //
//                                                                            //
//         ALL RIGHTS RESERVED. THIS MATERIAL CONTAINS THE VALUABLE           //
//                      PROPERTIES AND TRADE SECRETS OF                       //
//                                                                            //
//                                 Itron,                                     //
//                           BANGALORE, INDIA                                 //
//                                                                            //
//                  EMBODYING SUBSTANTIAL CREATIVE EFFORTS                    //
//   AND TRADE SECRETS, CONFIDENTIAL INFORMATION, IDEAS AND EXPRESSIONS, NO   //
//    PART OF WHICH MAY BE REPRODUCED OR TRANSMITTED IN ANY FORM OR BY ANY    //
//   MEANS ELECTRONIC, MECHANICAL, OR OTHERWISE, INCLUDING PHOTOCOPYING AND   //
//        RECORDING OR IN CONNECTION WITH ANY INFORMATION STORAGE OR          //
//         RETRIEVAL SYSTEM WITHOUT THE PERMISSION IN WRITING FROM            //
//                                  Itron, Inc.                               //
//                                                                            //
//                                 COPYRIGHT 2016                             //
//                                  Itron. Inc.                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

/*!************************************************************************//**
 * @file          agent_config.cpp
 * @brief         File to get and handle configrations from SDK
 * @date          16.Aug.2017
 * @author        Deepika Durgvanshi
 ******************************************************************************/

#include <iostream>
using namespace std;

#include <agent_metrology.h>
#include <agent_constants.h>
#include <agent_config.h>
#include <common.h>
#include <agent_feature.h>
#include <sstream>

// Other module headers
#include <Itron/AgentApi.h>
#include <common_metrology.h>

common::CConfigParser& g_objConfigParser = common::CConfigParser::GetConfigParserInstance();
common::CCommand& g_objCCommand = common::CCommand::GetCommandInstance();

static void RegisterAgentFeatureConfigCallbacks();
static void ApplyConfig(const uint32_t& i_featureId, ELogLevel i_eLogLevel=common::INFO);
static void UpdateConfigFromServer(const uint32_t& i_featureId);
static void InitializeTheFeature(uint32_t& i_featureId);

CAgentFeature g_objAgentFeature;

extern common::ELogLevel metrolLogLevel;
extern struct FeatureStatus g_stFeaturesStatus;
static common::ELogLevel configLogLevel = common::ERR ;

static stGeneralConfig genAgentFeatureConfig = {kDefaultFeatureEnabled, kDefaultLogLevel, kDefaultKeepLogLevelForSecs};
static stAgentFeatureConfig agentFeatureConfig= {(uint16_t)kDefaultVBelowThreshold, kDefaultCheckForVolt, (uint32_t)kDefaultCBelowThreshold, kDefaultCheckForCurrent};

static stCoutLogConfig stCoutConfig = {kuiIsEnabled, kuiDefaultNumLogFiles, kuiDefaultLogFileSize};
static stCallBackConfig stCllbckConfig = {kuiDefaultCllBckTimeOutSec};
static stConfiguration stCfg = {false};
static stArrayBufferConfig stArrayBuffConfig = {kuiBufferSize};
/**
    * @brief This function is use to update Generic configuration parameters
    *
*/
void UpdateGenFeatureConfgurations(const stCoutLogConfig i_stCoutConfig, const stCallBackConfig i_stCallBackConfig, const stConfiguration i_stCfg, const stArrayBufferConfig i_stArrayBuffCfg)
{
	//These functions are defined in Common_Util.cpp file
	UpdateCoutConfig(i_stCoutConfig);
	UpdateCallBackConfig(i_stCallBackConfig);
	UpdateConfiguration(i_stCfg);
	UpdateArrayBuffConfig(i_stArrayBuffCfg);
}

/**
    * @brief This function is use to update configuration parameters of the related class.
    *
*/
void UpdateAgentFeatureConfigurations(const stGeneralConfig i_GenAgentFeatureConfig, const stAgentFeatureConfig  i_AgentFeatureConfig )//!OCLINT
{
	#ifdef debugConfig
	cout << "UpdateAgentFeatureConfigurations(). " << endl ;
	cout << "\tGeneral Config: "  	<< (int)i_GenAgentFeatureConfig.uiFeatureEnabled << " "
									<< (int)i_GenAgentFeatureConfig.uiLogLevel << " "
									<< (int)i_GenAgentFeatureConfig.uiKeepLogLevelForSecs << endl;
	cout << "\tAgentFeature Config: "<< i_AgentFeatureConfig.VoltThreshold
									<< " agentFeatureConfig.CheckForVoltage: " << i_AgentFeatureConfig.CheckForVoltage << endl;
	#endif

	g_objAgentFeature.UpdateAgentFeatureConfig(i_GenAgentFeatureConfig, i_AgentFeatureConfig);
	bool bFeatureEnableStatus = CCommonMetrology::GetCommonMetrologyInstance()->GetFeatureEnableStatus();
	if(bFeatureEnableStatus != i_GenAgentFeatureConfig.uiFeatureEnabled)
	{
		CCommonMetrology::GetCommonMetrologyInstance()->SetFeatureEnableStatus(i_GenAgentFeatureConfig.uiFeatureEnabled);
		if(i_GenAgentFeatureConfig.uiFeatureEnabled && g_stFeaturesStatus.bIsAgentFeatureStarted)
		{
			SubscribeLids();
			SubscribeToMetrologyData();
		}
		else if (true == CCommonMetrology::GetCommonMetrologyInstance()->GetAgentSubscribeStatus())
		{
			DIAgentLogMsg(kuiPhaseNA, kuiAgentFeatureID, common::INFO, common::INFO,common::CONFIG,"AC.UpdVbTCfg Stat:(xml:%d, cmd line:%d), UnsubMetData",(int)i_GenAgentFeatureConfig.uiFeatureEnabled,(int)g_stFeaturesStatus.bIsAgentFeatureStarted);
			UnSubscribeFromMetrologyData();
		}
	}

}

/**
    * @brief This is the callback function called by ConfigParse module. It called after Configuration updated  processing is completed by ConfigParse module.
    *
*/
void UpdateConfigFromServer(const uint32_t& i_featureId)
{
	ApplyConfig(i_featureId);
}

/**
    * @brief This is called from callback function UpdateConfigFromServer which called from ConfigParser. This function apply received configuration.
    *
*/
static void ApplyConfig(const uint32_t& i_featureId, ELogLevel i_eLogLevel)
{

	cout << "AgentConfig.ApplyConfig(). i_featureId: " << i_featureId << endl;

	switch(i_featureId)
	{
		case kuiAgentFeatureID:			// Apply Configuration for AgentFeature 
		{
			#ifdef debugConfig
//			cout << "genAgentFeatureConfig.uiFeatureEnabled: " << (int)genAgentFeatureConfig.uiFeatureEnabled << " "
//				 << "genAgentFeatureConfig.uiLogLevel: " << (int)genAgentFeatureConfig.uiLogLevel << " "
//				 << "agentFeatureConfig.VoltThreshold: " << agentFeatureConfig.VoltThreshold << " "
//				 << "agentFeatureConfig.CheckForVoltage: " << agentFeatureConfig.CheckForVoltage <<endl;
			#endif
			stringstream streamStr;
			streamStr << "AC.AppCfg AgentFeature: [";
			streamStr << static_cast<int>(genAgentFeatureConfig.uiFeatureEnabled) << ", ";
			streamStr << static_cast<int>(genAgentFeatureConfig.uiLogLevel) << ", ";
			streamStr << genAgentFeatureConfig.uiKeepLogLevelForSecs << "]";
			streamStr << " [";
			streamStr << agentFeatureConfig.VoltThreshold << ", ";
			streamStr << static_cast<int>(agentFeatureConfig.CheckForVoltage) <<"]" << endl;

			DIAgentLogMsg(kuiPhaseNA, i_featureId, configLogLevel, i_eLogLevel,common::CONFIG,"%s", streamStr.str().c_str());
			UpdateAgentFeatureConfigurations(genAgentFeatureConfig, agentFeatureConfig);
		}
		break;
		default:
		{
			if(i_featureId == kuiGenericFeatureID)
			{
				#ifdef debugConfig
//				cout << "stCoutConfig.uiIsEnabled: " << (int)stCoutConfig.uiIsEnabled << " "
//						 << "stCoutConfig.uiNumLogFiles: " << (int)stCoutConfig.uiNumLogFiles << " "
//						 << "stCoutConfig.uiFileSize: " << (int)stCoutConfig.uiFileSize << " "
//						 << "stCllbckConfig.uiCallBackTimeOutSec: " << (int)stCllbckConfig.uiCallBackTimeOutSec << " "
				#endif
				stringstream streamStr;
				streamStr << "AC.AppCfg Gen: [";
				streamStr << static_cast<int>(stCoutConfig.uiIsEnabled) << ", ";
				streamStr << stCoutConfig.uiNumLogFiles << ", ";
				streamStr << stCoutConfig.uiFileSize << "]";
				streamStr << " [";
				streamStr << stCllbckConfig.uiCallBackTimeOutSec << "]";
				streamStr << " [";
				streamStr << static_cast<int>(stArrayBuffConfig.uiBufferSize) <<"]" << endl;

				DIAgentLogMsg(kuiPhaseNA, i_featureId, configLogLevel, i_eLogLevel,common::CONFIG,"%s", streamStr.str().c_str());
				UpdateGenFeatureConfgurations(stCoutConfig, stCllbckConfig, stCfg, stArrayBuffConfig);
			}
		}
		break;
	}
}

/****************************************************************
 * CALLBACK function definition for each configuration parameter
 ****************************************************************/

//CoutLog config
void RASetCoutLogIsEnabledCB(string i_strFolderName, string i_strParamName, stConfigVal i_stConfigVal)  //!OCLINT args i_strFolderName and i_strParamName provided if required to use
{
	stCoutConfig.uiIsEnabled = (uint8_t) i_stConfigVal.unParamVal.uiVal;
}

void RASetNumLogFilesCB(string i_strFolderName, string i_strParamName, stConfigVal i_stConfigVal)  //!OCLINT args i_strFolderName and i_strParamName provided if required to use
{
	stCoutConfig.uiNumLogFiles = i_stConfigVal.unParamVal.uiVal;
}

void RASetLogFileSizeCB(string i_strFolderName, string i_strParamName, stConfigVal i_stConfigVal)  //!OCLINT args i_strFolderName and i_strParamName provided if required to use
{
	stCoutConfig.uiFileSize = i_stConfigVal.unParamVal.uiVal;
}

void RASetCallBackTimeOutCB(string i_strFolderName, string i_strParamName, stConfigVal i_stConfigVal)  //!OCLINT args i_strFolderName and i_strParamName provided if required to use
{
	stCllbckConfig.uiCallBackTimeOutSec = i_stConfigVal.unParamVal.uiVal;
}

void RASetArrayBufferSizeCB(string i_strFolderName, string i_strParamName, stConfigVal i_stConfigVal)  //!OCLINT args i_strFolderName and i_strParamName provided if required to use
{
	stArrayBuffConfig.uiBufferSize = static_cast<uint8_t>(i_stConfigVal.unParamVal.uiVal);
}

void SetAgentFeatureGenLogLevelCB(string i_folderName, string i_paramName, stConfigVal i_stConfigVal) //!OCLINT args i_folderName and i_paramName provided if required to use
{
	genAgentFeatureConfig.uiLogLevel = (common::ELogLevel) i_stConfigVal.unParamVal.uiVal;
}

void SetAgentFeatureGenFeatureEnabledCB(string i_folderName, string i_paramName, stConfigVal i_stConfigVal) //!OCLINT args i_folderName and i_paramName provided if required to use
{
	genAgentFeatureConfig.uiFeatureEnabled = i_stConfigVal.unParamVal.bVal;
}

void SetAgentFeatureGenKeepLogLevelForSecsCB(string i_folderName, string i_paramName, stConfigVal i_stConfigVal) //!OCLINT args i_folderName and i_paramName provided if required to use
{
	genAgentFeatureConfig.uiKeepLogLevelForSecs = i_stConfigVal.unParamVal.uiVal;
}


void SetAgentFeatureThresholdVoltageCB(string i_folderName, string i_paramName, stConfigVal i_stConfigVal) //!OCLINT args i_folderName and i_paramName provided if required to use
{
	agentFeatureConfig.VoltThreshold = (uint16_t) i_stConfigVal.unParamVal.uiVal;
}


void SetAgentFeatureCheckForVoltageCB(string i_folderName, string i_paramName, stConfigVal i_stConfigVal)
{
	agentFeatureConfig.CheckForVoltage  = i_stConfigVal.unParamVal.bVal;
}

/**
    * @brief This is the callback function, it is use to register all configuration parameter callback function with ConfigParse's object.
    *
*/
static void RegisterAgentFeatureConfigCallbacks()
{
	string errorMsg = "";
	g_objConfigParser.RegisterConfigParamCallback(kuiAgentFeatureID, folder_general, FeatureState, SetAgentFeatureGenFeatureEnabledCB, errorMsg);
	g_objConfigParser.RegisterConfigParamCallback(kuiAgentFeatureID, folder_general, LogLevel, SetAgentFeatureGenLogLevelCB, errorMsg);
	g_objConfigParser.RegisterConfigParamCallback(kuiAgentFeatureID, folder_general, KeepLogLevelForSecs, SetAgentFeatureGenKeepLogLevelForSecsCB, errorMsg);

	g_objConfigParser.RegisterConfigParamCallback(kuiAgentFeatureID, folder_AgentFeature, ThresholdVoltage ,SetAgentFeatureThresholdVoltageCB, errorMsg);
	g_objConfigParser.RegisterConfigParamCallback(kuiAgentFeatureID, folder_AgentFeature, CheckForVoltage ,SetAgentFeatureCheckForVoltageCB, errorMsg);
}

/**
    * @brief This is the callback function, it is use to register all Generic configuration parameter callback function with ConfigParse's object.
    *
*/
static void RegisterGenericConfigCallback()
{
	string strErrorMsg = "";
	g_objConfigParser.RegisterConfigParamCallback(kuiGenericFeatureID, strFolderCoutLogger, strCoutEnabled, RASetCoutLogIsEnabledCB, strErrorMsg);
	g_objConfigParser.RegisterConfigParamCallback(kuiGenericFeatureID, strFolderCoutLogger, strNumLogFiles, RASetNumLogFilesCB, strErrorMsg);
	g_objConfigParser.RegisterConfigParamCallback(kuiGenericFeatureID, strFolderCoutLogger, strLogFileSize, RASetLogFileSizeCB, strErrorMsg);

	g_objConfigParser.RegisterConfigParamCallback(kuiGenericFeatureID, strFolderCallBackForHungAgent, strCallBackTimeOutSec, RASetCallBackTimeOutCB, strErrorMsg);

	g_objConfigParser.RegisterConfigParamCallback(kuiGenericFeatureID, strFolderArrayBuffer, strArrayBufferSize, RASetArrayBufferSizeCB, strErrorMsg);
}

/**
    * @brief This is the callback function of the commandConfig feature. Which is called by ConfigParse module.
    * @param[in] i_commandName It is the name of the command which need to execute.
    * @param[in] i_commandArg It is the argument for the command name( function) this has the present status of the features, if it has started or stopped
    *
*/
static void ConfigCommandCallbackFromAgent (const string i_commandName, const string i_commandArg)
{
	DIAgentLogMsg(kuiPhaseNA, kuiCommandConfigFeatureID, genAgentFeatureConfig.uiLogLevel, common::DEBUG,common::CONFIG,"Command config [CName, CValue] [%s, %s]", i_commandName.c_str(), i_commandArg.c_str());
}

/**
    * @brief This function use to initialize ConfigParse object for Command Configuration feature.
    *
*/
static void InitializeCommandFeature()
{
	string l_strError = "";

	g_objCCommand.InitCommand(g_objConfigParser, l_strError);
	g_objCCommand.RegisterCommand(g_objConfigParser, strTestCommand, &ConfigCommandCallbackFromAgent, l_strError);
	g_objCCommand.UpdateAPIServiceForCommand(g_objConfigParser, l_strError);
	g_objCCommand.SetCommandCallbackFlag(true);
}

/**
    * @brief This function is use to initialize ConfigParse's object for common::ELogLevel metrolLogLevel = kDefaultLogLevel ; .
    * @param[in] i_featureId  Feature Id
    *
*/
static void InitializeTheFeature(uint32_t i_featureId)
{
	//Get config parser object instance
	//common::CConfigParser&  obj_configParser = common::CConfigParser::GetConfigParserInstance();

	string errorMsg = "";

	if( false == g_objConfigParser.InitFeature(i_featureId, errorMsg) )
	{
		cout << "AgentConfig.InitializeTheFeature(). CNFG.InitializeFeatureConfigModule: " << errorMsg << endl;
	}

	switch (i_featureId)
	{
	case kuiAgentFeatureID:
		RegisterAgentFeatureConfigCallbacks();
		break;
	default:
		if(i_featureId == kuiGenericFeatureID)
		{
			RegisterGenericConfigCallback();
		}
		break;
	}

	if( false == g_objConfigParser.UpdateAPIServiceForFeature(i_featureId, errorMsg) )
	{
		cout << "AgentConfig.InitializeTheFeature(). CNFG.InitializeFeatureConfigModule: " << errorMsg << endl;		
		stringstream stringstr;
		stringstr.str("");
		stringstr << errorMsg << " for feature " << i_featureId << ". Using default" ;

		DIAgentLogMsg(kuiPhaseNA, i_featureId, common::ERR, common::ALERT,common::CONFIG,"%s", stringstr.str().c_str());
		ApplyConfig(i_featureId, common::ALERT);
	}

}

void InitializeFeatureConfigModule()
{
	cout<< "AgentConfig.InitializeFeatureConfigModule(). CNFG.InitializeFeatureConfigModule is called" << endl;
	string errorMsg = "";

	//Get config parser object instance
	common::CConfigParser& obj_configParser = common::CConfigParser::GetConfigParserInstance();

	//Set the agent ID for future usage
	obj_configParser.setAgentId(kuiAgentID);

	//Update Config module with the callback when all the tasks are completed
	obj_configParser.RegisterConfigurationUpdateCallback(UpdateConfigFromServer, errorMsg);

	InitializeTheFeature(kuiGenericFeatureID);
	InitializeTheFeature(kuiAgentFeatureID);
	InitializeCommandFeature();

}




